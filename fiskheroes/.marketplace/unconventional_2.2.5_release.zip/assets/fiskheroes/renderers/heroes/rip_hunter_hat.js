extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "fiskheroes:rip_hunter_layer1",
    "layer2": "fiskheroes:rip_hunter_pants",
    "pants_trenchcoat": "fiskheroes:rip_hunter_pants_trenchcoat",
    "boots": "fiskheroes:rip_hunter_boots",
    "boots_trenchcoat": "fiskheroes:rip_hunter_boots_trenchcoat",
    "hat": "fiskheroes:rip_hunter_hat"
});

function init(renderer) {
    parent.init(renderer);
    renderer.setTexture((entity, renderLayer) => {
        if (renderLayer == "LEGGINGS") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "pants_trenchcoat" : "layer2";
        }
        else if (renderLayer == "BOOTS") {
            return entity.getWornChestplate().suitType() == $SUIT_NAME ? "boots_trenchcoat" : "boots";
        }
        return "layer1";
    });

    renderer.showModel("CHESTPLATE", "head", "headwear", "body", "rightArm", "leftArm", "rightLeg", "leftLeg");
    renderer.fixHatLayer("CHESTPLATE");

    renderer.setItemIcons("rip_hunter_0", "rip_hunter_1", "rip_hunter_2", "rip_hunter_3")
}

function initEffects(renderer) {
    renderer.bindProperty("fiskheroes:energy_bolt").color.set(0x005EFF);

    var model_hat = renderer.createResource("MODEL", "fiskheroes:rip_hunter_hat");
    model_hat.texture.set("hat");

    hat = renderer.createEffect("fiskheroes:model").setModel(model_hat);
    hat.setOffset(0, 0.0, 0);
    hat.anchor.set("head");
    hat.setScale(1.025);
}

function render(entity, renderLayer, isFirstPersonArm) {
    
    hat.render();
}