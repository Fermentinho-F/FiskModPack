function continuePlaying(entity, sound) {
    if (entity.isAlive()) {
        return true;
    }
//FINISH AND FIX IDLE SOUNDS
    return false;
}
