function evaluate(mesh, x, y, width, length) {
    mesh.vertY += -0.42;
    mesh.vertZ += 0.18;
}
