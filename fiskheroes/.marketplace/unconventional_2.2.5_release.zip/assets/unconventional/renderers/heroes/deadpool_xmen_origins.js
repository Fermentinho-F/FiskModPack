extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "unconventional:marvel/deadpool_xmen_origins_layer1",
    "layer2": "unconventional:marvel/deadpool_xmen_origins_layer2",
    "full": "unconventional:marvel/deadpool_xmen_origins_full.tx.json",
    "null": "unconventional:null",
    "eyes": "unconventional:marvel/deadpool_xmen_origins_eyes",
    "eyes_layer": "unconventional:marvel/deadpool_xmen_origins_eye_layer",
    "skeleton": "unconventional:marvel/adamantium_skeleton"
});

var utils = implement("fiskheroes:external/utils");

var overlay_eyes;
var overlay_eye_layer;

var blade;

var head_skeleton

function init(renderer) {
    parent.init(renderer);
	
	renderer.setTexture((entity, renderLayer) => entity.getInterpolatedData('fiskheroes:teleport_timer')>0 ? renderLayer == "LEGGINGS" ? "null" : "null" : renderLayer == "LEGGINGS" ? "layer2" : "layer1");

	
}

function initEffects(renderer) {
	
	// utils.bindParticles(renderer, "unconventional:warp");
	// .setCondition(entity => entity.getData("fiskheroes:speeding") && entity.isSprinting() && (entity.ticksExisted() % 7) <= 1);
	
	overlay_eyes = renderer.createEffect("fiskheroes:overlay");
    overlay_eyes.texture.set("eyes", "eyes");
	
	overlay_eye_layer = renderer.createEffect("fiskheroes:overlay");
    overlay_eye_layer.texture.set("eyes_layer");
	
	var blade_model = renderer.createResource("MODEL", "unconventional:deadpool_xmen_origins_blade");
	blade_model.bindAnimation("unconventional:deadpool_xmen_origins_blade").setData((entity, data) => {
		data.load(1-entity.getInterpolatedData('fiskheroes:blade_timer'));
	})
	.priority = 1;
	blade_model.texture.set("layer1");
	blade_model.generateMirror();
	blade = renderer.createEffect("fiskheroes:model").setModel(blade_model);
	blade.anchor.set("rightArm");
	
	var cloth_model = renderer.createResource("MODEL", "unconventional:deadpool_xmen_origins_cloth");
	cloth_model.bindAnimation("unconventional:deadpool_xmen_origins_cloth").setData((entity, data) => {
		data.load(0, 1);
	})
	.priority = 1;
    cloth_model.texture.set("layer2");
	cloth = renderer.createEffect("fiskheroes:model").setModel(cloth_model);
    cloth.anchor.set("body");
	
	var head_skeleton_model = renderer.createResource("MODEL", "unconventional:head_skeleton");
    head_skeleton_model.texture.set("skeleton");
	head_skeleton = renderer.createEffect("fiskheroes:model").setModel(head_skeleton_model);
    head_skeleton.anchor.set("head");

	var body_skeleton_model = renderer.createResource("MODEL", "unconventional:body_skeleton");
    body_skeleton_model.texture.set("skeleton");
	body_skeleton = renderer.createEffect("fiskheroes:model").setModel(body_skeleton_model);
    body_skeleton.anchor.set("body");

	var rightArm_skeleton_model = renderer.createResource("MODEL", "unconventional:rightArm_skeleton");
    rightArm_skeleton_model.texture.set("skeleton");
	rightArm_skeleton = renderer.createEffect("fiskheroes:model").setModel(rightArm_skeleton_model);
    rightArm_skeleton.anchor.set("rightArm");
	
	var leftArm_skeleton_model = renderer.createResource("MODEL", "unconventional:leftArm_skeleton");
    leftArm_skeleton_model.texture.set("skeleton");
	leftArm_skeleton = renderer.createEffect("fiskheroes:model").setModel(leftArm_skeleton_model);
    leftArm_skeleton.anchor.set("leftArm");
	
	var rightLeg_skeleton_model = renderer.createResource("MODEL", "unconventional:rightLeg_skeleton");
    rightLeg_skeleton_model.texture.set("skeleton");
	rightLeg_skeleton = renderer.createEffect("fiskheroes:model").setModel(rightLeg_skeleton_model);
    rightLeg_skeleton.anchor.set("rightLeg");
	
	var leftLeg_skeleton_model = renderer.createResource("MODEL", "unconventional:leftLeg_skeleton");
    leftLeg_skeleton_model.texture.set("skeleton");
	leftLeg_skeleton = renderer.createEffect("fiskheroes:model").setModel(leftLeg_skeleton_model);
    leftLeg_skeleton.anchor.set("leftLeg");
	
	
	var head_model = renderer.createResource("MODEL", "unconventional:player/head_player");
    head_model.texture.set("full");
	head = renderer.createEffect("fiskheroes:model").setModel(head_model);
    head.anchor.set("head");

	var body_model = renderer.createResource("MODEL", "unconventional:player/body_player");
    body_model.texture.set("full");
	body = renderer.createEffect("fiskheroes:model").setModel(body_model);
    body.anchor.set("body");

	var rightArm_model = renderer.createResource("MODEL", "unconventional:player/rightArm_player");
    rightArm_model.texture.set("full");
	rightArm = renderer.createEffect("fiskheroes:model").setModel(rightArm_model);
    rightArm.anchor.set("rightArm");
	
	var leftArm_model = renderer.createResource("MODEL", "unconventional:player/leftArm_player");
    leftArm_model.texture.set("full");
	leftArm = renderer.createEffect("fiskheroes:model").setModel(leftArm_model);
    leftArm.anchor.set("leftArm");
	
	var rightLeg_model = renderer.createResource("MODEL", "unconventional:player/rightLeg_player");
    rightLeg_model.texture.set("full");
	rightLeg = renderer.createEffect("fiskheroes:model").setModel(rightLeg_model);
    rightLeg.anchor.set("rightLeg");
	
	var leftLeg_model = renderer.createResource("MODEL", "unconventional:player/leftLeg_player");
    leftLeg_model.texture.set("full");
	leftLeg = renderer.createEffect("fiskheroes:model").setModel(leftLeg_model);
    leftLeg.anchor.set("leftLeg");

	utils.setOpacity(renderer, 0.999, 1.0, 1);
	
	var shake = renderer.bindProperty("fiskheroes:camera_shake").setCondition(entity => {
        shake.factor = 0.1*entity.getInterpolatedData("fiskheroes:teleport_timer") + 0.2*entity.getInterpolatedData("fiskheroes:beam_charge") + entity.getInterpolatedData("fiskheroes:beam_shooting_timer");
		shake.intensity = 0.0;
        return true;
    });
	
	utils.bindBeam(renderer, "fiskheroes:charged_beam", "unconventional:cyclops_xmen_chaos_blast", "head", 0xFF0019, [
        { "firstPerson": [2.2, 0.0, 2.0], "offset": [2.2, -3.3, -4.0], "size": [1.0, 0.5] },
        { "firstPerson": [-2.2, 0.0, 2.0], "offset": [-2.2, -3.3, -4.0], "size": [1.0, 0.5] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));

}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
	
	addAnimationWithData(renderer, "deadpool.BLADE", "unconventional:blade_arm_rotZ", "fiskheroes:blade_timer");
	addAnimationWithData(renderer, "deadpool.WARP", "unconventional:warp", "fiskheroes:teleport_timer").priority = -1;
	addAnimationWithData(renderer, "basic.CHARGED_BEAM", "unconventional:deadpool_xmen_origins_charged_beam", "fiskheroes:beam_shooting_timer").priority = -8;
		
	
	addAnimation(renderer, "deadpool.SLICE", "unconventional:double_slice").setData((entity, data) => data.load(entity.getPunchTimerInterpolated()*entity.getInterpolatedData('fiskheroes:blade_timer') ))
    .priority = -8;

}

function render(entity, renderLayer, isFirstPersonArm) {
	var blade_timer = entity.getInterpolatedData('fiskheroes:blade_timer');
	var teleport_timer = entity.getInterpolatedData('fiskheroes:teleport_timer');
	var teleport_scale0 = Math.max(Math.min(1.052*Math.sin(1.6*Math.PI*teleport_timer), 0.0),-1);
	var teleport_scale1 = Math.max(Math.min(3.3*Math.sin(1.9*Math.PI*teleport_timer), 0.1),-1);
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
			overlay_eyes.opacity = entity.getInterpolatedData('fiskheroes:beam_charge')*1-1.5*teleport_timer;;
			overlay_eyes.render();
			overlay_eye_layer.opacity = Math.min(entity.getInterpolatedData('fiskheroes:beam_charge')*2, 1)*1-1.5*teleport_timer;
			overlay_eye_layer.render();
			
			head_skeleton.setScale(1+teleport_scale0);
			head_skeleton.opacity = 1-1*teleport_timer;
			head_skeleton.render();
			
			if (teleport_timer>0) {
				head.setScale(1+teleport_scale1);
				head.opacity = 1-1.5*teleport_timer;
				head.render();
			}
            
        }
        else if (renderLayer == "CHESTPLATE") {
			body_skeleton.setScale(1+teleport_scale0);
			body_skeleton.opacity = 1-1*teleport_timer;
            body_skeleton.render();
			leftArm_skeleton.setScale(1+teleport_scale0);
			leftArm_skeleton.opacity = 1-1*teleport_timer;
            leftArm_skeleton.render();

			if (teleport_timer>0) {
				body.setScale(1+teleport_scale1);
				body.opacity = 1-1.5*teleport_timer;
				body.render();
				leftArm.setScale(1+teleport_scale1);
				leftArm.opacity = 1-1.5*teleport_timer;
				leftArm.render();
			}
        }
		else if (renderLayer == "LEGGINGS") {
			cloth.setScale(1+teleport_scale1);
			cloth.opacity = 1-1.5*teleport_timer;
			cloth.render();
			
			rightLeg_skeleton.setScale(1+teleport_scale0);
			rightLeg_skeleton.opacity = 1-1*teleport_timer;
			leftLeg_skeleton.setScale(1+teleport_scale0);
			leftLeg_skeleton.opacity = 1-1*teleport_timer;
            rightLeg_skeleton.render();
            leftLeg_skeleton.render();
			
			if (teleport_timer>0) {
				rightLeg.setScale(1+teleport_scale1);
				rightLeg.opacity = 1-1.5*teleport_timer;
				leftLeg.setScale(1+teleport_scale1);
				leftLeg.opacity = 1-1.5*teleport_timer;
				rightLeg.render();
				leftLeg.render();
			}
        }
    }
	if (renderLayer == "CHESTPLATE") {	
		blade.setScale(1+teleport_scale0);
		blade.opacity = 1-1*teleport_timer;
		blade.mirror = !isFirstPersonArm;
		// blade.setOffset(0, -12*(1-blade_timer), 0);
		blade.render();
		
		rightArm_skeleton.setScale(1+teleport_scale0);
		rightArm_skeleton.opacity = 1-1*teleport_timer;
		rightArm_skeleton.render();
		
		if (teleport_timer>0) {
			rightArm.setScale(1+teleport_scale1);
			rightArm.opacity = 1-1.5*teleport_timer;
			rightArm.render();
		}
	}
	
}
