extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "unconventional:dc/batman_dceu_tactical_layer1",
    "layer2": "unconventional:dc/batman_dceu_tactical_layer2",
    "cape": "unconventional:dc/batman_dceu_tactical_cape"
});

var utils = implement("fiskheroes:external/utils");
var glide = implement("unconventional:external/gliding_anim");
var capes = implement("unconventional:external/capes");

var cape;

function init(renderer) {
    parent.init(renderer);
    
    renderer.setItemIcon("CHESTPLATE", "batman_dceu_tactical_1");
    renderer.setItemIcon("LEGGINGS", "batman_dceu_tactical_2");
    renderer.setItemIcon("BOOTS", "batman_dceu_tactical_3");
}

function initEffects(renderer) {
    var physics = renderer.createResource("CAPE_PHYSICS", null);
    physics.maxFlare = 0.4;
    physics.flareDegree = 1.5;
    physics.flareFactor = 1.2;
    physics.flareElasticity = 5;

    cape = capes.createGlider(renderer, 24, "fiskheroes:cape_batman.mesh.json", physics);
    cape.effect.texture.set("cape");

    renderer.bindProperty("fiskheroes:equipment_wheel").color.set(0x000000);
    renderer.bindProperty("fiskheroes:equipped_item").setItems([
        { "anchor": "body", "scale": 0.7, "offset": [-4.5, 10.5, 0.4], "rotation": [110.0, 5.0, 0.0] }
    ]);
}

function initAnimations(renderer) {
    parent.initAnimations(renderer);
		
	glide.addGlideAnimation(renderer, "gliding.FLIGHT", "unconventional:flight/gliding_default.anim.json");
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm && renderLayer == "CHESTPLATE") {
        cape.render(entity, entity.getInterpolatedData("fiskheroes:wing_animation_timer")/1.5, entity.getInterpolatedData("fiskheroes:wing_animation_timer"), Math.max((1.1*entity.getInterpolatedData("fiskheroes:wing_animation_timer") + Math.min(Math.max(entity.motionY()+1.0, -0.7), 0) ), 0));
    }
}
