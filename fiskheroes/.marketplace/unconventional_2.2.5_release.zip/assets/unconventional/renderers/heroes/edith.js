extend("fiskheroes:hero_basic");
loadTextures({
    "glasses": "unconventional:marvel/edith_glasses",
    "null": "unconventional:null"
    
});

var utils = implement("fiskheroes:external/utils");

var glasses;

function init(renderer) {
    parent.init(renderer);

    renderer.setTexture((entity, renderLayer) => {
        return "null";
    });

    renderer.showModel("HELMET", "head", "headwear");
    renderer.fixHatLayer("HELMET");
}

function initEffects(renderer) {
    var model_glasses = renderer.createResource("MODEL", "unconventional:edith_glasses");
    model_glasses.texture.set("glasses");

    glasses = renderer.createEffect("fiskheroes:model").setModel(model_glasses);
    glasses.setOffset(0.0, 0.0, 0.0).setRotation(0.0, 0.0, 0.0).setScale(1.0);
    glasses.anchor.set("head");

}

function render(entity, renderLayer, isFirstPersonArm) {
    if (renderLayer == "HELMET") {
        glasses.render();
    }
}