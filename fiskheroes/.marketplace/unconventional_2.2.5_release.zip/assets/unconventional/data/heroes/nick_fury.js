function init(hero) {
    hero.setName("Nick Fury");
    hero.setTier(3);
   
    hero.setHelmet("Eyepatch");   
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:sw_mp9}", true, item => item.nbt().getString("WeaponType") == 'unconventional:sw_mp9');
	
    hero.addPowers("unconventional:shield_uniform");
	
    hero.addAttribute("PUNCH_DAMAGE", 5.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.1, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
   
    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

    hero.setKeyBindEnabled(isKeyBindEnabled);

}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()) )&& !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_GUN");
}

function canAim(entity) {
    return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));
}