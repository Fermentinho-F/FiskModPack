function init(hero) {
    hero.setName("Ghost");
    hero.setTier(5);
    
    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.legs");
    hero.setBoots("item.superhero_armor.piece.boots");
    
    hero.addPowers("unconventional:quantum_mutation");
	
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.35, 1);
	hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
	hero.addAttribute("STEP_HEIGHT", 1.0, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("INTANGIBILITY", "Phase", 1);
    hero.addKeyBind("INVISIBILITY", "Invisibility", 2);
	
    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

    hero.setKeyBindEnabled(isKeyBindEnabled);
    hero.setModifierEnabled(isModifierEnabled);

    hero.setTickHandler((entity, manager) => {
        if (entity.getData("fiskheroes:intangible")){

		    manager.setData(entity, "fiskheroes:flying", true);
            manager.setData(entity, "fiskheroes:hovering", true);
        }
        else {
            manager.setData(entity, "fiskheroes:flying", false);
            manager.setData(entity, "fiskheroes:hovering", false);
        }

        if (entity.getData("fiskheroes:dyn/intangibility_cooldown") == 1) {
            manager.setData(entity, "fiskheroes:intangible", false)
        }
    });

    hero.addSoundEvent("EQUIP", "unconventional:ghost_loop");
    
}


function isModifierEnabled(entity, modifier) {
	var x = entity.posX();
    var y = entity.posY();
    var z = entity.posZ();
    var blockxp = entity.world().getBlock(x+0.25, y, z) != "minecraft:air";
    var blockxn = entity.world().getBlock(x-0.25, y, z) != "minecraft:air";
	var blockyp = entity.world().getBlock(x, y+0.25, z) != "minecraft:air";
    var blockyn = entity.world().getBlock(x, y-0.25, z) != "minecraft:air";
    var blockzp = entity.world().getBlock(x, y, z-0.25) != "minecraft:air";
    var blockzn = entity.world().getBlock(x, y, z+0.25) != "minecraft:air";
	
	switch (modifier.name()) {
	case "fiskheroes:flight":
        return entity.getData("fiskheroes:intangible") && ( (blockxp) || (blockxn) || (blockzp) || (blockzn) && !entity.isInWater()) && !entity.isInWater();
	case "fiskheroes:invisibility":
        return !entity.isPunching() && !entity.getData("fiskheroes:aiming");

    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon())) && !entity.getData("fiskheroes:aiming");
    case "INTANGIBILITY":
        return !(entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon())) && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_GUN");
}

function canAim(entity) {
    return entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon());
}
