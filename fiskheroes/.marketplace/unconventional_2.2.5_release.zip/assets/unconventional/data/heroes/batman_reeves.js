function init(hero) {
    hero.setName("Batman");
    hero.setVersion("Reeves");
    hero.setTier(6);
    
    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);
    
    hero.addPowers("unconventional:the_batsuit");
	
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 8.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);

    hero.addKeyBind("UTILITY_BELT", "Toggle Utility Belt", 1);

    hero.setHasPermission(hasPermission);

    hero.setTickHandler((entity, manager) => {

        //Diving
        var motionY1 = entity.motionY();

        //Grappling
        var ground_distance = entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid();
        var sprinting = entity.isSprinting();
        var punching = entity.isPunching();
        if (!ground_distance && !punching && entity.getHeldItem().name() == "fiskheroes:grappling_gun" && motionY1 > 0.6) {
            manager.setData(entity, "unconventional:dyn/grapple", true); 
        }
        else manager.setData(entity, "unconventional:dyn/grapple", false);

    });

}

function hasPermission(entity, permission) {
    return permission == "USE_GRAPPLING_GUN";
}