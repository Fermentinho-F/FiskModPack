// OUTBURST STATS
var max_range = 8;
var damage = 8;

function init(hero) {
    hero.setName("Spider-Man/Miles Morales");
    hero.setVersion("PS5");
    hero.setTier(7);

    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("unconventional:mutated_spider_physiology", "unconventional:web_shooters_miles_ps5");

    hero.addAttribute("FALL_RESISTANCE", 11.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.5, 0);
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.45, 1);
    hero.addAttribute("STEP_HEIGHT", 0.5, 0);
    hero.addAttribute("IMPACT_DAMAGE", 0.4, 1);

    hero.addKeyBind("UTILITY_BELT", "key.webShooters", 1);
    hero.addKeyBind("CHARGED_BEAM", "Venom Burst", 1);
    hero.addKeyBind("WEB_ZIP", "key.webZip", 2);
    hero.addKeyBindFunc("func_WEB_SWINGING", webSwingingKey, "key.webSwinging", 3);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 4);
    hero.addKeyBind("INVIS", "Camouflage", 4);
    hero.addKeyBind("CHARGE_ENERGY", "Venom", 5);

    hero.addSoundEvent("PUNCH", "unconventional:miles_venom_punch");
    
    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.supplyFunction("canDischargeEnergy", false);

    hero.addDamageProfile("BURST", {
		"types": {
          "ENERGY": 1.0,
          "ELECTRICITY": 1.0
        },
        "properties": {
          "COOK_ENTITY": true,
          "HEAT_TRANSFER": 30,
          "DAMAGE_DROPOFF": 0.4,
          "EFFECTS": [
            {
              "id": "fiskheroes:flashbang",
              "duration": 140,
              "amplifier": 2,
              "chance": 1
            },
            {
              "id": "fiskheroes:disable_speed",
              "duration": 80,
              "amplifier": 1,
              "chance": 0.4
            }
          ]
        }
	});

    hero.setTickHandler((entity, manager) => {
        var t = entity.getData("fiskheroes:dyn/superhero_landing_ticks");
        var venom = entity.getInterpolatedData("unconventional:dyn/venom_boost_cooldown");
        var charge = entity.getInterpolatedData("fiskheroes:energy_charge");
        var charging = entity.getData("fiskheroes:energy_charging");

        //VENOM
        //0.41 - bar 1 full
        //0.65 - bar 2 full
        //0.95 - bar 3 full
            //NOTE: numbers arent exact but well use them anyways,  close enough

        if (t == 0 && entity.isSneaking() && !entity.isSprinting() && !entity.isOnGround() && entity.motionY() < -0.95 && entity.world().blockAt(entity.pos().add(0, -2.0, 0)).isSolid()) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", t = 14);
            entity.playSound("fiskheroes:modifier.gliding.cape.disable", 1, 0.9 - Math.random() * 0.2);
        } else if (t > 0) {
            manager.setData(entity, "fiskheroes:dyn/superhero_landing_ticks", --t);
        }

        manager.incrementData(entity, "fiskheroes:dyn/superhero_landing_timer", 4, 10, t > 0);

        manager.incrementData(entity, "unconventional:dyn/sneaking_timer", 40, (entity.isSneaking() && entity.isOnGround() && !entity.getData("fiskheroes:moving")));
        manager.incrementData(entity, "unconventional:dyn/perch_timer", 6, entity.getData("unconventional:dyn/sneaking_timer") == 1);


        
        if (entity.getData("unconventional:dyn/invisibility_timer") == 1 && entity.getData("unconventional:dyn/invisibility") && !entity.getData("fiskheroes:invisible")) {
            manager.setData(entity, "fiskheroes:invisible", true);
        }

        if (entity.getData("unconventional:dyn/invisibility_timer") !=1 && !entity.getData("unconventional:dyn/invisibility") && entity.getData("fiskheroes:invisible")) {
            manager.setData(entity, "fiskheroes:invisible", false);
        }

        if (entity.getData("fiskheroes:web_aim_right_timer") + entity.getData("fiskheroes:web_aim_left_timer") + (entity.getPunchTimer() + entity.getData("fiskheroes:prev_web_swinging_timer")) != 0 && venom != 1) {
            manager.setData(entity, "unconventional:dyn/venom_boost_cooldown", venom + 0.002);
        }

        //Venom Set
        if (venom > 0.95) {
            manager.setData(entity, "unconventional:dyn/venom_boost_cooldown", 0.95);
        }
        if (venom < 0.17) {
            manager.setData(entity, "unconventional:dyn/venom_boost_cooldown", 0.175);
        }
        if (!charging) {
            manager.setData(entity, "fiskheroes:energy_charge", 0);
        }

        //Venom Flight
        if (entity.getData("fiskheroes:flying") && entity.getData("unconventional:dyn/venom_boost_timer") == 0 && entity.getData("fiskheroes:energy_charging")) {
            manager.setData(entity, "unconventional:dyn/venom_boost_cooldown", venom-0.26);
            manager.setData(entity, "unconventional:dyn/venom_boost_timer", 1);
        }
        if (entity.getData("unconventional:dyn/venom_boost_timer") != 0) {
            manager.incrementData(entity, "unconventional:dyn/venom_boost_timer", 18, false, true);
        }
        if (entity.getData("unconventional:dyn/venom_boost_timer") == 0 && entity.getData("fiskheroes:flying")) {
            manager.setData(entity, "fiskheroes:flying", false);
        }

        if (entity.getData('fiskheroes:beam_charging')){
            manager.setData(entity, "fiskheroes:hovering", true);
        }
        else {
            manager.setData(entity, "fiskheroes:hovering", false);
        }

        outburst(hero, entity, manager);
    });
}

function outburst(hero, entity, manager) {
    var venom = entity.getInterpolatedData("unconventional:dyn/venom_boost_cooldown");
    
    if (entity.getData('fiskheroes:beam_shooting_timer') == 1 && venom >= 0.94) {
        manager.setData(entity, "unconventional:dyn/venom_boost_cooldown", 0.175);
    }

    if (entity.getData("fiskheroes:beam_shooting_timer") > 0) {
        var list = entity.world().getEntitiesInRangeOf(entity.pos(), max_range * entity.getData("fiskheroes:beam_shooting_timer"));
        for (var i = 0; i < list.size(); ++i) {
            var other = list.get(i);
            if (other.isLivingEntity() && !entity.equals(other) && entity.world().isUnobstructed(entity.pos().add(0, 1, 0), other.pos().add(0, 1, 0))) {
                other.hurtByAttacker(hero, "BURST", "%s was electrocuted by %s", damage, entity);
            }
        }
    }
}

function webSwingingKey(player, manager) {
    var flag = player.getData("fiskheroes:web_swinging");

    if (!flag) {
        manager.setDataWithNotify(player, "fiskheroes:prev_utility_belt_type", player.getData("fiskheroes:utility_belt_type"));
        manager.setDataWithNotify(player, "fiskheroes:utility_belt_type", -1);
    }

    manager.setDataWithNotify(player, "fiskheroes:web_swinging", !flag);
    return true;
}

function isModifierEnabled(entity, modifier) {
    var venomC = entity.getData("unconventional:dyn/venom_boost_cooldown");
    var venomT = entity.getData("unconventional:dyn/venom_boost_timer");
    var charge = entity.getInterpolatedData("fiskheroes:energy_charge");
    var charging = entity.getData("fiskheroes:energy_charging");
    switch (modifier.name()) {
    case "fiskheroes:web_swinging":
        return entity.getHeldItem().isEmpty() && entity.getData("fiskheroes:utility_belt_type") == -1;
    case "fiskheroes:leaping":
        return modifier.id() == "springboard" == (entity.getData("fiskheroes:ticks_since_swinging") < 5);
    case "fiskheroes:controlled_flight":
        return (!entity.isOnGround() && entity.isSprinting() && !entity.getData("fiskheroes:web_swinging_timer")) && ((venomC >= 0.41) || venomC < 0.41 && venomT != 0);
    case "unconventional:dyn/venom_boost":
        return !entity.getData("fiskheroes:flight_boost_timer");
    case "fiskheroes:invisibility":
        return !entity.isPunching() && !(entity.getData("fiskheroes:web_aim_right_timer") + entity.getData("fiskheroes:web_aim_left_timer"));
    case "fiskheroes:energy_manipulation":
        return venomC >= 0.41 || venomC < 0.41;
    case "fiskheroes:damage_bonus":
        return charge == 1 && (venomC >= 0.41 || venomC < 0.41);
        
    case "fiskheroes:flight":
        return entity.getData('fiskheroes:beam_charging');
    case "fiskheroes:hover":
        return entity.getData('fiskheroes:beam_charging');
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
    var charge = entity.getInterpolatedData("fiskheroes:energy_charge");
    var venomC = entity.getData("unconventional:dyn/venom_boost_cooldown");
    switch (keyBind) {
    case "UTILITY_BELT":
        return charge != 1;
    case "CHARGED_BEAM":
        return charge == 1 && venomC >= 0.94 && entity.getData('fiskheroes:beam_shooting_timer') == 0;
    case "WEB_SWINGING":
        return entity.getHeldItem().isEmpty();
    case "INVIS":
        return entity.isSneaking();
    case "SLOW_MOTION":
        return !entity.isSneaking();
    case "CHARGE_ENERGY":
        return venomC >= 0.41;
    default:
        return true;
    }
}
