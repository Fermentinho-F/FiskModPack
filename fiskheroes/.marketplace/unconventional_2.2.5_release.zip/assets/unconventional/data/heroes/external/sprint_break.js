function tick(entity, manager, min_motion) {
	if (entity.getData('unconventional:dyn/sprint_break_timer')==1) {
		manager.setData(entity, "unconventional:dyn/sprint_break", false);
		manager.setData(entity, 'unconventional:dyn/prev_speed_sprint_timer', -1);
	}
	if (!(entity.isSprinting() || entity.getData('fiskheroes:speeding')) && entity.isOnGround()) {
		if (entity.getData('unconventional:dyn/prev_speed_sprint_timer')>entity.getData('fiskheroes:dyn/speed_sprint_timer') && entity.getData('fiskheroes:ticks_since_sprinting') > 0 && entity.getData('fiskheroes:ticks_since_sprinting') < 7) {
			manager.setData(entity, "unconventional:dyn/sprint_break", true);
		}
		else {
			manager.setData(entity, "unconventional:dyn/sprint_break", false);
		}
	}
	if (entity.isSprinting() && entity.getData('fiskheroes:dyn/speed_sprint_timer') > 0) {
		if (entity.motion().length()>min_motion) {
			manager.setData(entity, 'unconventional:dyn/prev_speed_sprint_timer', entity.getData('fiskheroes:dyn/speed_sprint_timer'));
		}
		else {
			manager.setData(entity, 'unconventional:dyn/prev_speed_sprint_timer', -1);
		}
	}
	else if (entity.motion().length()>min_motion ) {
		manager.setData(entity, 'unconventional:dyn/prev_speed_sprint_timer', -1);
	}
	
	manager.incrementData(entity, "unconventional:dyn/sprint_break_timer", 3, 8,entity.getData('unconventional:dyn/sprint_break'));

	
}
