function tick(entity, manager) {

	var canMsgHappen = true;
	
    var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	
	var list_dome = manager.newTagList();
	
	var lore = manager.newTagList();
	var display = nbt.getCompoundTag("display");
	
	var domeId = entity.getData("fiskheroes:lightsout_id");
	var dome = entity.world().getEntityById(domeId);
	if (dome.exists()) {
		var contained = dome.as("SHADOWDOME").getContainedEntities();
		manager.setTagList(nbt, "DOME_ENTITIES", list_dome);
		
		
		for (var i = 0; i < contained.size(); i++) {
			var other = contained.get(i);
			if ((other.getUUID() === entity.getUUID() )&& other.isLivingEntity() ) {
				for (var y = 0; y < contained.size(); y++) {
					var othery = contained.get(y);
					if ((othery.getUUID() !== entity.getUUID() )&& othery.isLivingEntity() ) {
						var target = manager.newCompoundTag();
						manager.setString(target, "EntityName", othery.getEntityName() ? othery.getEntityName() : "Unknown");
						manager.setString(target, "Name", othery.getName() ? othery.getName() : "Unknown");
						manager.setString(target, "Health", othery.getHealth() + "/" + othery.getMaxHealth());
						manager.setInteger(target, "Oxygen", othery.getAir());

						manager.appendTag(list_dome, target);

						
					}
				}
				return true;
			}
		}
		
	}
	
	//Display
	var x = entity.getData('unconventional:dyn/i');
	var list_dome = nbt.getTagList('DOME_ENTITIES');
	
	// if (list_dome != null || list_dome.tagCound() > 0) {
	// 	var tag = list_dome.getCompoundTag(x)

	// 	var name = tag.getString('Name')
	// 	var health = tag.getString('Health')
	// 	var oxygen = tag.getInteger('Oxygen')

		
	// 	manager.appendString(lore, "\u00A7r\u00A7b| Entities: " + (x+1) + "/" + list_dome.tagCount());
	// 	manager.setTagList(display, "Lore", lore);
	// 	manager.appendString(lore, "\u00A7r\u00A7b| Currently Tracking: " + name);
	// 	manager.setTagList(display, "Lore", lore);
	// 	manager.appendString(lore, "\u00A7r\u00A7b| Health: " + health + " | Oxygen: " + oxygen);
	// 	manager.setTagList(display, "Lore", lore);


		
	// 	manager.setCompoundTag(nbt, "display", display);
	// }
	
	if (x > list_dome.tagCount()) {
		manager.setData(entity, 'unconventional:dyn/i', list_dome.tagCount()-1)
	}
}

// function display(player, manager) {
// 	var x = player.getData('unconventional:dyn/i');
// 	var item = player.getEquipmentInSlot(3);
// 	var nbt = item.nbt();
// 	var list_dome = nbt.getTagList('DOME_ENTITIES');

// 	if (list_dome != null && list_dome.tagCount() > 0) {
// 		var tag = list_dome.getCompoundTag(x);
// 		var name = tag.getString('Name')
// 		var health = tag.getString('Health');
// 		var oxygen = tag.getInteger('Oxygen');
// 		if (PackLoader.getSide() == "CLIENT") {
// 			PackLoader.printChat("\u00A7r\u00A7b| Entities: " + "\u00A73" + (x+1) + "/" + list_dome.tagCount());
// 			PackLoader.printChat(" \u00A7r\u00A7b| Currently Tracking: " + "\u00A7c" + name);
// 			PackLoader.printChat(" \u00A7r\u00A7b| Health: " + "\u00A7a" + health);
// 			PackLoader.printChat(" \u00A7r\u00A7b| Oxygen: " + "\u00A73" + oxygen);
// 		}
// 	}
// }
