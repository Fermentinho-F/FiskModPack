function init(hero) {
    hero.setName("Winter Soldier");
    hero.setTier(6);
    
    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("unconventional:winter_soldier_program", "unconventional:titanium_arm");
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:m4a1}", true, item => item.nbt().getString("WeaponType") == 'unconventional:m4a1');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:scorpion_vz}", true, item => item.nbt().getString("WeaponType") == 'unconventional:scorpion_vz');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:p220st}", true, item => item.nbt().getString("WeaponType") == 'unconventional:p220st');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:cop_357_derringer}", true, item => item.nbt().getString("WeaponType") == 'unconventional:cop_357_derringer');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:gerber_mk_ii}", true, item => item.nbt().getString("WeaponType") == 'unconventional:gerber_mk_ii');
	
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.35, 1);
   
    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBindFunc("SWITCH_MODE", switchMode,"Switch Mode", 1);
    hero.addKeyBind("SHIELD_THROW", "key.shieldThrow", 1);
    hero.addKeyBind("UTILITY_BELT", "Toggle Smoke Bombs", 1);
    hero.addKeyBind("SHIELD", "Block", 2);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

    hero.setKeyBindEnabled(isKeyBindEnabled);
	hero.setTickHandler((entity, manager) => {
		var nbt = entity.getWornChestplate().nbt();	
		if (nbt.getBoolean("SelectCooldown")) {
			manager.setBoolean(nbt, "SelectCooldown", false);
		}
		///BLOCKING_CONS
		manager.incrementData(entity, "unconventional:dyn/shield_damaged_timer", 0, 5, entity.getHeldItem().isEmpty() && entity.getData('fiskheroes:ticks_since_shield_damaged') > 0 && entity.getData('fiskheroes:ticks_since_shield_damaged') < 3);
		if (entity.getData("unconventional:dyn/shield_damaged_timer") == 0) {
			manager.setData(entity, "unconventional:dyn/punch", Math.floor(Math.random()*4));
		}
		
		var shield_req = entity.getHeldItem().isEmpty() && entity.getData('fiskheroes:ticks_since_shield_damaged') > 0 && entity.getData('fiskheroes:ticks_since_shield_damaged') < 6
		manager.incrementData(entity, "unconventional:dyn/shield_1_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 0 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_2_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 1 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_3_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 2 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_4_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 3 && shield_req);

	});
}

function switchMode(player, manager) {
	var nbt = player.getWornChestplate().nbt();	
	var nbt_gun = player.getHeldItem().nbt();
	if (!nbt.getBoolean("SelectCooldown")) {
	if (nbt_gun.getString("WeaponType") == 'unconventional:m4a1') {
		manager.setShort(nbt, "Ammo_bullets", nbt_gun.getShort('Ammo'));
		
		manager.setString(nbt_gun, "WeaponType", 'unconventional:m4a1_grenade_launcher');
		manager.setShort(nbt_gun, "Ammo", nbt.getShort('Ammo_grenade'));
		manager.setBoolean(nbt, "SelectCooldown", true);
	}
	else if (nbt_gun.getString("WeaponType") == 'unconventional:m4a1_grenade_launcher' ) {
		manager.setShort(nbt, "Ammo_grenade", nbt_gun.getShort('Ammo'));
		
		manager.setString(nbt_gun, "WeaponType", 'unconventional:m4a1');
		manager.setShort(nbt_gun, "Ammo", nbt.getShort('Ammo_bullets'));
		manager.setBoolean(nbt, "SelectCooldown", true);
	}
	}
    return true;
}

function isKeyBindEnabled(entity, keyBind) {
	var nbt = entity.getWornChestplate().nbt();	
	var nbt_gun = entity.getHeldItem().nbt();
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()) )&& !entity.getData("fiskheroes:aiming") && !(entity.isSneaking() && entity.getHeldItem().name() == "fisktag:weapon" && (nbt_gun.getString('WeaponType') == 'unconventional:m4a1' || nbt_gun.getString('WeaponType') == 'unconventional:m4a1_grenade_launcher'));
    case "SWITCH_MODE":
        return !nbt.getBoolean("SelectCooldown") && !entity.getData("fiskheroes:aiming") && (entity.isSneaking() && entity.getHeldItem().name() == "fisktag:weapon" && (nbt_gun.getString('WeaponType') == 'unconventional:m4a1' || nbt_gun.getString('WeaponType') == 'unconventional:m4a1_grenade_launcher'));
	case "SHIELD_THROW":
        return entity.getHeldItem().name() == "fiskheroes:captain_americas_shield";
    case "UTILITY_BELT":
        return entity.getHeldItem().isEmpty();
	case "SHIELD":
        return entity.getHeldItem().isEmpty();
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_GUN" || permission == "USE_SHIELD");
}

function canAim(entity) {
    return  (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));
}