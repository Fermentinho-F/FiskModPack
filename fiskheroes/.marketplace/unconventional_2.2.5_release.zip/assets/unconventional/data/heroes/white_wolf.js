function init(hero) {
    hero.setName("Bucky Barnes");
    hero.setTier(6);
    
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");

    hero.addPowers("unconventional:winter_soldier_program", "unconventional:vibranium_arm");
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:m249_saw}", true, item => item.nbt().getString("WeaponType") == 'unconventional:m249_saw');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:p220st}", true, item => item.nbt().getString("WeaponType") == 'unconventional:p220st');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:gerber_mk_ii}", true, item => item.nbt().getString("WeaponType") == 'unconventional:gerber_mk_ii');
	
    hero.addAttribute("PUNCH_DAMAGE", 7.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 5.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 7.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.4, 1);
   
    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("SHIELD_THROW", "key.shieldThrow", 1);
    hero.addKeyBind("SHIELD", "Block", 2);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

    hero.setKeyBindEnabled(isKeyBindEnabled);
	hero.setTickHandler((entity, manager) => {
		var nbt = entity.getWornChestplate().nbt();	
		if (nbt.getBoolean("SelectCooldown")) {
			manager.setBoolean(nbt, "SelectCooldown", false);
		}
		///BLOCKING_CONS
		manager.incrementData(entity, "unconventional:dyn/shield_damaged_timer", 0, 5, entity.getHeldItem().isEmpty() && entity.getData('fiskheroes:ticks_since_shield_damaged') > 0 && entity.getData('fiskheroes:ticks_since_shield_damaged') < 3);
		if (entity.getData("unconventional:dyn/shield_damaged_timer") == 0) {
			manager.setData(entity, "unconventional:dyn/punch", Math.floor(Math.random()*4));
		}
		
		var shield_req = entity.getHeldItem().isEmpty() && entity.getData('fiskheroes:ticks_since_shield_damaged') > 0 && entity.getData('fiskheroes:ticks_since_shield_damaged') < 6
		manager.incrementData(entity, "unconventional:dyn/shield_1_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 0 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_2_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 1 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_3_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 2 && shield_req);
		manager.incrementData(entity, "unconventional:dyn/shield_4_timer", 3, 5, entity.getData("unconventional:dyn/punch") == 3 && shield_req);

	});
}

function isKeyBindEnabled(entity, keyBind) {
	var nbt = entity.getWornChestplate().nbt();	
	var nbt_gun = entity.getHeldItem().nbt();
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()) ) && !entity.getData("fiskheroes:aiming");
    case "SHIELD_THROW":
        return entity.getHeldItem().name() == "fiskheroes:captain_americas_shield";
	case "SHIELD":
        return entity.getHeldItem().isEmpty();
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_GUN" || permission == "USE_SHIELD");
}

function canAim(entity) {
    return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));
}