var detectiveModeRange = 20; // RANGE IN BLOCKS

function init(hero) {
    hero.setName("Robin/Arkham Knight");
    hero.setVersion("Rocksteady");
    hero.setTier(6);
    
    hero.setHelmet("item.superhero_armor.piece.mask");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:robin_rocksteady_bostaff}", true, item => item.nbt().getString("WeaponType") == 'unconventional:robin_rocksteady_bostaff');
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:explosive_gel}", true, item => item.nbt().getString("WeaponType") == 'unconventional:explosive_gel');
    
    hero.addPowers("unconventional:robin_armor_ak");
	
    hero.addAttribute("PUNCH_DAMAGE", 6.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 6.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "Toggle Utility Belt", 1);

    hero.addKeyBindFunc("func_DETECTIVE_MODE", detectiveKey,"Detective Mode", 5);
    hero.addKeyBindFunc("DISPLAY", display, "Scan Target", 2);
    hero.addKeyBindFunc("func_CYCLE_TARGET", cycle_target,"Cycle Target", 4);

    hero.setModifierEnabled(isModifierEnabled);
	hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

    hero.addAttributeProfile("SLIDING", slidingProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.addSoundEvent("MASK_OPEN", "fiskheroes:cowl_mask_open");
    hero.addSoundEvent("MASK_CLOSE", "fiskheroes:cowl_mask_close");

    hero.setTickHandler((entity, manager) => {

        var bostaff = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType") == 'unconventional:robin_rocksteady_bostaff';
        manager.incrementData(entity, "unconventional:dyn/bostaff_timer", 10, 14, bostaff);
        var nbtB = entity.getWornChestplate().nbt();
        if (nbtB.getBoolean("SelectCooldown")) {
            manager.setBoolean(nbtB, "SelectCooldown", false);
        }

        manager.incrementData(entity, "unconventional:dyn/shield_timer", 6, (entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().isWeapon()) && entity.as("PLAYER").isUsingItem());

        //SLIDING
        var requierments = sneaking && motion && ground && water && slide_cooldown;
        var requierments1 = sneaking && motion1 && ground && water && slide_cooldown;
        var sneaking = entity.isSneaking();
        var motion = entity.motion().length() > 0.2;
        var motion1 = entity.motion().length() < -0.2;
        var cooldown = entity.getData("unconventional:dyn/sprint_cooldown") > 0;
        var moving = entity.getData("fiskheroes:moving");
        var ground = entity.isOnGround();
        var water = entity.isInWater();
        var slide_cooldown = entity.getData("unconventional:dyn/sliding_cooldown") == 0;
        var superhero_landing = entity.getData("fiskheroes:dyn/superhero_landing_timer");

        if (sneaking && cooldown && ground && !water && slide_cooldown) {

            manager.setData(entity, "unconventional:dyn/sliding", true);
            manager.setData(entity, "fiskheroes:flying", true);

        }

        manager.setData(entity, "fiskheroes:flying", false);
    
        if (entity.getData("unconventional:dyn/sliding_timer")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 0.8575);
        }
        if (entity.getData("fiskheroes:gliding")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 1);
        }

        //Diving
        var gliding = entity.getData("fiskheroes:gliding");
        var motionY1 = entity.motionY();

        //Grappling
        var ground_distance = entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid();
        var sprinting = entity.isSprinting();
        var punching = entity.isPunching();
        if (!gliding && !ground_distance && !punching && entity.getHeldItem().name() == "fiskheroes:grappling_gun" && motionY1 > 0.6) {
            manager.setData(entity, "unconventional:dyn/grapple", true); 
        }
        else manager.setData(entity, "unconventional:dyn/grapple", false);


    //Detective Mode
    var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	
	var list_dome = manager.newTagList();
	var display = nbt.getCompoundTag("display");
	
	if (entity.getData("unconventional:dyn/goggle")) {
		var contained = entity.world().getEntitiesInRangeOf(entity.pos(), detectiveModeRange);
		manager.setTagList(nbt, "DOME_ENTITIES", list_dome);
		for (var i = 0; i < contained.size(); i++) {
			var other = contained.get(i);
			if (!entity.equals(other) && other.isLivingEntity() ) {
                var target = manager.newCompoundTag();
                manager.setString(target, "EntityName", other.getEntityName() ? other.getEntityName() : "Unknown");
                manager.setString(target, "Name", other.getName() ? other.getName() : "Unknown");
                manager.setString(target, "Health", other.getHealth() + "/" + other.getMaxHealth());
                manager.setInteger(target, "Oxygen", other.getAir());

                manager.appendTag(list_dome, target);
            }
		}
	}
        manager.setCompoundTag(nbt, "display", display);
    });
}

function getAttributeProfile(entity) {
	if (entity.getData("unconventional:dyn/sliding_timer")) {
        return "SLIDING";
    } 
    
    return null;
}

function slidingProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 1.5, 1);
    profile.addAttribute("SPRINT_SPEED", -0.25, 1);

}

function detectiveKey(entity, manager) {
    var d_m = entity.getData("unconventional:dyn/goggle");
    
    manager.setData(entity, "unconventional:dyn/goggle", !d_m);
    
    if (PackLoader.getSide() == "CLIENT") {
        if (d_m) {
            PackLoader.printChat("\u00A7b| Detective Mode: \u00A7cDisabled");
            entity.playSound("unconventional:dm.d", 1.0, 1);
        }
        else {
            PackLoader.printChat("\u00A7b| Detective Mode: \u00A7aEnabled");
            entity.playSound("unconventional:dm.a", 1.0, 1);
        }
    }

    return false;
}

function cycle_target(entity, manager) {
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	
	var list_dome = nbt.getTagList('DOME_ENTITIES');
	
	var i = entity.getData('unconventional:dyn/i');

	var lenght = list_dome.tagCount();
	
	if (!entity.isSneaking() ) {
		manager.setDataWithNotify(entity, 'unconventional:dyn/i', i == lenght-1 ? 0 : i + 1 );
		entity.playSound("unconventional:scan.zone.cycle", 1.0, (0.9 + Math.random() * 0.1));
	}
	else if (entity.isSneaking() ) {
		manager.setDataWithNotify(entity, 'unconventional:dyn/i', i == 0 ? lenght-1 : i - 1 );
		entity.playSound("unconventional:scan.zone.cycle", 1.0, (0.7 + Math.random() * 0.1));
	}
    if (lenght > 1) {
        display(entity, manager);
    }
    return false;
}

function display(entity, manager) {
	var x = entity.getData('unconventional:dyn/i');
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	var list_dome = nbt.getTagList('DOME_ENTITIES');

	if (list_dome != null && list_dome.tagCount() > 0) {
		var tag = list_dome.getCompoundTag(x);
		var name = tag.getString('Name')
		var health = tag.getString('Health');
		var oxygen = tag.getInteger('Oxygen');
		if (PackLoader.getSide() == "CLIENT") {
            PackLoader.printChat("\u00A7r\u00A7b| Entities: " + "\u00A73" + (x+1) + "/" + list_dome.tagCount());
            PackLoader.printChat(" \u00A7r\u00A7b| Currently Tracking: " + "\u00A7c" + name);
            PackLoader.printChat(" \u00A7r\u00A7b| Health: " + "\u00A7a" + health);
            PackLoader.printChat(" \u00A7r\u00A7b| Oxygen: " + "\u00A73" + oxygen);
		}
	}
    else if (list_dome != null && list_dome.tagCount() == 0) {
		if (PackLoader.getSide() == "CLIENT") {
            PackLoader.printChat("\u00A7r\u00A7b| Entities: " + "\u00A7cNo Entities Detected.");
		}
    }
    return false;
}

function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        return entity.getData("unconventional:dyn/sliding") || entity.getData("fiskheroes:gliding");
    case modifier.id() == "sliding_transformation":
        return !entity.getData("fiskheroes:aiming") && entity.isSprinting() && entity.isOnGround() && !entity.isInWater() && entity.getData("unconventional:dyn/sliding_cooldown") == 0;
    default:
        return true;
    
    }
}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "DISPLAY":
        return entity.getData("unconventional:dyn/goggle") && entity.getHeldItem().name() != 'fiskheroes:suit_data_drive';
    case "GUN_RELOAD":
        return ((entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel') && !entity.getHeldItem().isWeapon()) )&& !entity.getData("fiskheroes:aiming");
    case "UTILITY_BELT":
        return !entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel');
    case "func_CYCLE_TARGET":
        return entity.getData("unconventional:dyn/goggle");
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    switch (permission) {
        case "MELEE_BOSTAFF_SHIELD":
            return !entity.getData("fiskheroes:gliding");
        case "USE_GRAPPLING_GUN":
            return true
        case "USE_EXPLOSIVE_GEL":
            return true
    default:
        return true;
    }
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel');
}