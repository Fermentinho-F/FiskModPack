function init(hero) {
    hero.setName("Batman/Tactical");
    hero.setVersion("DCEU");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);

    hero.addPowers("unconventional:batsuit_tactical");
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 10.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.3, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.5, 1);

    hero.addKeyBind("UTILITY_BELT", "key.utilityBelt", 1);

    hero.setHasProperty((entity, property) => property == "MASK_TOGGLE");
    hero.setHasPermission((entity, permission) => permission == "USE_GRAPPLING_GUN");


    hero.setTickHandler((entity, manager) => {

        manager.setData(entity, "fiskheroes:flying", false);
    
        if (entity.getData("fiskheroes:gliding")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 1);
        }

        //Diving
        var gliding = entity.getData("fiskheroes:gliding");
        var motionY1 = entity.motionY();

        //Grappling
        var ground_distance = entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid();
        var sprinting = entity.isSprinting();
        var punching = entity.isPunching();
        if (!gliding && !ground_distance && !punching && entity.getHeldItem().name() == "fiskheroes:grappling_gun" && motionY1 > 0.6) {
            manager.setData(entity, "unconventional:dyn/grapple", true); 
        }
        else manager.setData(entity, "unconventional:dyn/grapple", false);

    });
}
