function init(hero) {
    hero.setName("Five");
    hero.setVersion("The Umbrella Academy");
    hero.setTier(1);
    
    hero.setChestplate("item.superhero_armor.piece.jacket");
    hero.setLeggings("Shorts");
    hero.setBoots("item.superhero_armor.piece.shoes");
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:fire_axe}", true, item => item.nbt().getString("WeaponType") == 'unconventional:fire_axe');
    
    hero.addPowers("unconventional:space_time_manipulation");
	
    hero.addAttribute("FALL_RESISTANCE", 4.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 0.5, 0);
    hero.addAttribute("PUNCH_DAMAGE", 2.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.15, 1);
    hero.addAttribute("WEAPON_DAMAGE", 5.5, 0);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("SLOW_MOTION", "key.slowMotion", 4);
    hero.addKeyBindFunc("TELEPORT", teleport, "Teleport", 5);	
    
    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);
    
    hero.setTierOverride(getTierOverride);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.setDefaultScale(0.85);

}

function teleport(player, manager) {
	manager.setData(player, 'fiskheroes:teleport_timer', 0);
	manager.setData(player, 'fiskheroes:teleport_delay', 10);
    return true;
}

function getTierOverride(entity) {
    return 0;

}

function isKeyBindEnabled(entity, keyBind) {
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()) ) && !entity.getData("fiskheroes:aiming");
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_GUN");
}

function canAim(entity) {
    return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));
}