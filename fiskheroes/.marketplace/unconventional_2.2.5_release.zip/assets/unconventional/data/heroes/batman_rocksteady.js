var landing = implement("unconventional:external/batman_rocksteady_superhero_landing");
var detectiveModeRange = 20; // RANGE IN BLOCKS

function init(hero) {
    hero.setName("Batman/Arkham Knight");
    hero.setVersion("Rocksteady");
    hero.setTier(7);
    
    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:explosive_gel}", true, item => item.nbt().getString("WeaponType") == 'unconventional:explosive_gel');
    
    hero.addPowers("unconventional:batsuit_ak");
	
    hero.addAttribute("PUNCH_DAMAGE", 6.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 3.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.5, 0);
    hero.addAttribute("FALL_RESISTANCE", 7.0, 0);
    hero.addAttribute("SPRINT_SPEED", 0.35, 1);
    hero.addAttribute("IMPACT_DAMAGE", 0.6, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "Toggle Utility Belt", 1);
	
	hero.addKeyBindFunc("func_DATA_DRIVE_HACK", suit_data_drive_hacking, "Hack Suit Data Drive", 1);
	hero.addKeyBindFunc("func_COPY", copy_paste_data, "Copy Data", 2);
	hero.addKeyBindFunc("func_PASTE", copy_paste_data, "Paste Data", 2);
	hero.addKeyBindFunc("func_DELETE", delete_data, "Delete Data", 3);

    hero.addKeyBindFunc("func_DETECTIVE_MODE", detectiveKey,"Detective Mode", 5);
    hero.addKeyBindFunc("DISPLAY", display, "Scan Target", 2);
    hero.addKeyBindFunc("func_CYCLE_TARGET", cycle_target,"Cycle Target", 4);

	hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.setHasPermission(hasPermission);
    hero.supplyFunction("canAim", canAim);

	hero.addAttributeProfile("SLIDING", slidingProfile);
    hero.addAttributeProfile("LANDING", landingProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setTickHandler((entity, manager) => {

        var sequencer = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType") == 'unconventional:cryptographic_sequencer';
        manager.incrementData(entity, "unconventional:dyn/sequencer_timer", 10, 14, sequencer);
        var nbtC = entity.getWornChestplate().nbt();
        if (nbtC.getBoolean("SelectCooldown")) {
            manager.setBoolean(nbtC, "SelectCooldown", false);
        }
        
		var item = entity.getEquipmentInSlot(3);
		var nbt = item.nbt();
		var suit_data_drive_hacking = nbt.getBoolean('suit_data_drive_hacking');
		
		if (suit_data_drive_hacking && entity.getHeldItem().name() != 'fiskheroes:suit_data_drive') {
			manager.setBoolean(nbt, 'suit_data_drive_hacking', false)
		}

        //SLIDING
        var requierments = sneaking && motion && ground && water && slide_cooldown;
        var requierments1 = sneaking && motion1 && ground && water && slide_cooldown;
        var sneaking = entity.isSneaking();
        var motion = entity.motion().length() > 0.2;
        var motion1 = entity.motion().length() < -0.2;
        var cooldown = entity.getData("unconventional:dyn/sprint_cooldown") > 0;
        var moving = entity.getData("fiskheroes:moving");
        var ground = entity.isOnGround();
        var water = entity.isInWater();
        var slide_cooldown = entity.getData("unconventional:dyn/sliding_cooldown") == 0;
        var superhero_landing = entity.getData("fiskheroes:dyn/superhero_landing_timer");

        if (sneaking && cooldown && ground && !water && slide_cooldown && !superhero_landing) {

            manager.setData(entity, "unconventional:dyn/sliding", true);
            manager.setData(entity, "fiskheroes:flying", true);
        }

        manager.setData(entity, "fiskheroes:flying", false);
    
        if (entity.getData("unconventional:dyn/sliding_timer")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 0.8575);
        }
        if (entity.getData("fiskheroes:gliding")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 1);
        }

        //Diving
        var gliding = entity.getData("fiskheroes:gliding");
        var motionY1 = entity.motionY();

        //Grappling
        var ground_distance = entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid();
        var sprinting = entity.isSprinting();
        var punching = entity.isPunching();
        if (!gliding && !ground_distance && !punching && entity.getHeldItem().name() == "fiskheroes:grappling_gun" && motionY1 > 0.6) {
            manager.setData(entity, "unconventional:dyn/grapple", true); 
        }
        else manager.setData(entity, "unconventional:dyn/grapple", false);

        landing.tick(entity, manager);


    //Detective Mode
    var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	
	var list_dome = manager.newTagList();
	var display = nbt.getCompoundTag("display");
	
	if (entity.getData("unconventional:dyn/goggle")) {
		var contained = entity.world().getEntitiesInRangeOf(entity.pos(), detectiveModeRange);
		manager.setTagList(nbt, "DOME_ENTITIES", list_dome);

        if (entity.getData("unconventional:dyn/i") >= contained.size()) {
            manager.setData(entity, "unconventional:dyn/i", 1);
        }
        
		for (var i = 0; i < contained.size(); i++) {
			var other = contained.get(i);
			if (!entity.equals(other) && other.isLivingEntity() ) {
                var target = manager.newCompoundTag();
                manager.setString(target, "EntityName", other.getEntityName() ? other.getEntityName() : "Unknown");
                manager.setString(target, "Name", other.getName() ? other.getName() : "Unknown");
                manager.setString(target, "Health", other.getHealth() + "/" + other.getMaxHealth());
                manager.setInteger(target, "Oxygen", other.getAir());

                manager.appendTag(list_dome, target);
            }
		}
	}
        manager.setCompoundTag(nbt, "display", display);
    });
}

function getAttributeProfile(entity) {
	if (entity.getData("unconventional:dyn/sliding_timer")) {
        return "SLIDING";
    } 
    if (entity.getData("fiskheroes:dyn/superhero_landing_timer")) {
        return "LANDING";
    }
    
    return null;
}

function slidingProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 1.5, 1);
    profile.addAttribute("SPRINT_SPEED", -0.25, 1);

}
function landingProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("FALL_RESISTANCE", 1.0, 1);

}

function detectiveKey(entity, manager) {
    var d_m = entity.getData("unconventional:dyn/goggle");
    
    manager.setData(entity, "unconventional:dyn/goggle", !d_m);
    
    if (PackLoader.getSide() == "CLIENT") {
        if (d_m) {
            PackLoader.printChat("\u00A7b| Detective Mode: \u00A7cDisabled");
            entity.playSound("unconventional:dm.d", 1.0, 1);
        }
        else {
            PackLoader.printChat("\u00A7b| Detective Mode: \u00A7aEnabled");
            entity.playSound("unconventional:dm.a", 1.0, 1);
        }
    }

    return false;
}

function cycle_target(entity, manager) {
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	
	var list_dome = nbt.getTagList('DOME_ENTITIES');
	
	var i = entity.getData('unconventional:dyn/i');

	var lenght = list_dome.tagCount();
	
	if (!entity.isSneaking() ) {
		manager.setDataWithNotify(entity, 'unconventional:dyn/i', i == lenght-1 ? 0 : i + 1 );
		entity.playSound("unconventional:scan.zone.cycle", 1.0, (0.9 + Math.random() * 0.1));
	}
	else if (entity.isSneaking() ) {
		manager.setDataWithNotify(entity, 'unconventional:dyn/i', i == 0 ? lenght-1 : i - 1 );
		entity.playSound("unconventional:scan.zone.cycle", 1.0, (0.7 + Math.random() * 0.1));
	}
    if (lenght > 1) {
        display(entity, manager);
    }
    return false;
}

function display(entity, manager) {
	var x = entity.getData('unconventional:dyn/i');
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	var list_dome = nbt.getTagList('DOME_ENTITIES');

	if (list_dome != null && list_dome.tagCount() > 0) {
		var tag = list_dome.getCompoundTag(x);
		var name = tag.getString('Name')
		var health = tag.getString('Health');
		var oxygen = tag.getInteger('Oxygen');
		if (PackLoader.getSide() == "CLIENT") {
            PackLoader.printChat("\u00A7r\u00A7b| Entities: " + "\u00A73" + (x+1) + "/" + list_dome.tagCount());
            PackLoader.printChat(" \u00A7r\u00A7b| Currently Tracking: " + "\u00A7c" + name);
            PackLoader.printChat(" \u00A7r\u00A7b| Health: " + "\u00A7a" + health);
            PackLoader.printChat(" \u00A7r\u00A7b| Oxygen: " + "\u00A73" + oxygen);
		}
	}
    else if (list_dome != null && list_dome.tagCount() == 0) {
		if (PackLoader.getSide() == "CLIENT") {
            PackLoader.printChat("\u00A7r\u00A7b| Entities: " + "\u00A7cNo Entities Detected.");
		}
    }
    return false;
}

function suit_data_drive_hacking(player, manager) {
	var item = player.getEquipmentInSlot(3);
    var nbt = item.nbt();
	var suit_data_drive_hacking = nbt.getBoolean('suit_data_drive_hacking');
	
	manager.setBoolean(nbt, 'suit_data_drive_hacking', suit_data_drive_hacking == true ? false : true);
    return true;
}

function copy_paste_data(player, manager) {
	var item = player.getEquipmentInSlot(3);
	var item_held = player.getHeldItem();
    var nbt = item.nbt();
	var nbt_held = item_held.nbt();
	var SuitList = nbt_held.getStringList("Suits");
	var StoredList = nbt.getStringList("StoredList");
	
	///copy

	if (!player.isSneaking() ) {
		if (SuitList.tagCount() == 0) {
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7b| No Data To Copy");
                return false;
            }
            return false;
		}
		else {
			manager.setTagList(nbt, "StoredList" ,SuitList);
			player.playSound("unconventional:data.drive.copy", 1.0, (0.9 + Math.random() * 0.1));
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7b| Data Copied:");
            }
			for (var i = 0; i < SuitList.tagCount(); ++i) {
                if (PackLoader.getSide() == "CLIENT") {
                    PackLoader.printChat(" \u00A7r\u00A7b| > " + SuitList.getString(i));
                }
			}
			return false;
		}
	}
	///paste
	else if (player.isSneaking() ) {
		if (StoredList.tagCount() == 0) {
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7b| No Data To Print");
                return false;
            }
			return false;
		}
		else {
			manager.setTagList(nbt_held, 'Suits', StoredList);
			player.playSound("unconventional:data.drive.paste", 1.0, (0.7 + Math.random() * 0.1));
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7b| Data Pasted:");
            }

			for (var i = 0; i < StoredList.tagCount(); ++i) {
                if (PackLoader.getSide() == "CLIENT") {
                    PackLoader.printChat(" \u00A7r\u00A7b| > " + StoredList.getString(i));
                }
			}
			return false;
		}
	}
	
    return true;
}


function delete_data(player, manager) {
    var item = player.getEquipmentInSlot(3);
    var item_held = player.getHeldItem();
    var nbt = item.nbt();
    var nbt_held = item_held.nbt();
    var SuitList = nbt_held.getStringList("Suits");

        if (SuitList.tagCount() == 0) {
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7c| Empty");
            }
            return false;
        }
        else {
            if (PackLoader.getSide() == "CLIENT") {
                PackLoader.printChat("\u00A7r\u00A7c| Data Deleted:");
            }
            for (var i = 0; i < SuitList.tagCount(); ++i) {
                if (PackLoader.getSide() == "CLIENT") {
                    PackLoader.printChat(" \u00A7r\u00A7c| > " + SuitList.getString(i));
                }
            }
            manager.removeTag(nbt_held, "Suits");
            player.playSound("unconventional:data.drive.delete", 1.0, (0.6 + Math.random() * 0.1));

            return false;
        }
}


function isModifierEnabled(entity, modifier) {
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        return entity.getData("unconventional:dyn/sliding") || entity.getData("fiskheroes:gliding");
    case modifier.id() == "sliding_transformation":
        return entity.isOnGround() && !entity.isInWater() && entity.getData("unconventional:dyn/sliding_cooldown") == 0;
    default:
        return true;
    
    }
}

function isKeyBindEnabled(entity, keyBind) {
	var item = entity.getEquipmentInSlot(3);
    var nbt = item.nbt();
	var suit_data_drive_hacking = nbt.getBoolean('suit_data_drive_hacking');
	var sneaking = entity.isSneaking();
	
    switch (keyBind) {
    case "DISPLAY":
        return entity.getData("unconventional:dyn/goggle") && entity.getHeldItem().name() != 'fiskheroes:suit_data_drive';
    case "func_CYCLE_TARGET":
        return entity.getData("unconventional:dyn/goggle");
    case "GUN_RELOAD":
        return ((entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel') && !entity.getHeldItem().isWeapon()) )&& !entity.getData("fiskheroes:aiming");
	case "UTILITY_BELT":
        return !entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel') && entity.getHeldItem().name() != 'fiskheroes:suit_data_drive';
	case "func_DATA_DRIVE_HACK":
			return suit_data_drive_hacking || entity.getHeldItem().name() == 'fiskheroes:suit_data_drive';	
			
			case "func_COPY":
				return suit_data_drive_hacking && !sneaking;
			case "func_PASTE":
				return suit_data_drive_hacking && sneaking;
			case "func_DELETE":
				return suit_data_drive_hacking;	
	
    default:
        return true;
    }
}

function hasPermission(entity, permission) {
    return entity.getData('fiskheroes:reload_timer') == 0 && (permission == "USE_EXPLOSIVE_GEL" || permission == "USE_GRAPPLING_GUN");
}

function canAim(entity) {
    return entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType").startsWith('unconventional:explosive_gel');
}