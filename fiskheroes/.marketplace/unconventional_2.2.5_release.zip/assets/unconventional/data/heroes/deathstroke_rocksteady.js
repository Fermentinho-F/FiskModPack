function init(hero) {
    hero.setName("hero.fiskheroes.deathstroke_dceu.name");
    hero.setVersion("Rocksteady");
    hero.setTier(6);

    hero.setHelmet("item.superhero_armor.piece.helmet");
    hero.setChestplate("item.superhero_armor.piece.chestpiece");
    hero.setLeggings("item.superhero_armor.piece.pants");
    hero.setBoots("item.superhero_armor.piece.boots");
    hero.addPrimaryEquipment("fiskheroes:chokuto", true, item => !item.nbt().getBoolean("Dual"));
    hero.addPrimaryEquipment("fiskheroes:chokuto", true, item => !item.nbt().getBoolean("Dual"));
    hero.addPrimaryEquipment("fiskheroes:desert_eagle", true, item => !item.nbt().getBoolean("Dual"));
    hero.addPrimaryEquipment("fisktag:weapon{WeaponType:unconventional:deathstroke_rocksteady_bostaff}", true, item => item.nbt().getString("WeaponType") == 'unconventional:deathstroke_rocksteady_bostaff');
    hero.addPrimaryEquipment("fiskheroes:grappling_gun", true);

    hero.addPowers("unconventional:deathstroke_rocksteady_armor", "unconventional:enhanced_physiology");
    hero.addAttribute("PUNCH_DAMAGE", 7.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 4.5, 0);
    hero.addAttribute("JUMP_HEIGHT", 1.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 5.5, 0);
    hero.addAttribute("SPRINT_SPEED", 0.2, 1);

    hero.addKeyBind("AIM", "key.aim", -1);
    hero.addKeyBind("GUN_RELOAD", "key.reload", 1);
    hero.addKeyBind("UTILITY_BELT", "key.grenades", 1);
    hero.addKeyBindFunc("func_CYCLE_WEAPON_FLASHBAND", cycleGrenadeKey, "Cycle Grenade | \u00A7b\u00A7lFlashbang", 4);
    hero.addKeyBindFunc("func_CYCLE_WEAPON_EXPLOSIVE", cycleGrenadeKey, "Cycle Grenade | \u00A74\u00A7lExplosive", 4);
    hero.addKeyBindFunc("func_CYCLE_WEAPON_SMOKE", cycleGrenadeKey, "Cycle Grenade | \u00A77\u00A7lSmoke", 4);
    hero.addKeyBindFunc("func_CYCLE_WEAPON_NEURAL", cycleGrenadeKey, "Cycle Grenade | \u00A7a\u00A7lNeural", 4);

    hero.setModifierEnabled(isModifierEnabled);
    hero.setKeyBindEnabled(isKeyBindEnabled);

    hero.addAttributeProfile("SLIDING", slidingProfile);
    hero.setAttributeProfile(getAttributeProfile);

    hero.setHasPermission((entity, permission) => permission == "USE_GUN" || permission == "USE_GRAPPLING_GUN");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));

    hero.setTickHandler((entity, manager) => {		
        
        var bostaff = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString("WeaponType") == 'unconventional:deathstroke_rocksteady_bostaff';
        manager.incrementData(entity, "unconventional:dyn/bostaff_timer", 10, 14, bostaff);
        var nbt = entity.getWornChestplate().nbt();
        if (nbt.getBoolean("SelectCooldown")) {
            manager.setBoolean(nbt, "SelectCooldown", false);
        }

        //SLIDING
        var requierments = sneaking && motion && ground && water && slide_cooldown;
        var requierments1 = sneaking && motion1 && ground && water && slide_cooldown;
        var sneaking = entity.isSneaking();
        var motion = entity.motion().length() > 0.2;
        var motion1 = entity.motion().length() < -0.2;
        var cooldown = entity.getData("unconventional:dyn/sprint_cooldown") > 0;
        var moving = entity.getData("fiskheroes:moving");
        var ground = entity.isOnGround();
        var water = entity.isInWater();
        var slide_cooldown = entity.getData("unconventional:dyn/sliding_cooldown") == 0;
        var superhero_landing = entity.getData("fiskheroes:dyn/superhero_landing_timer");

        if (sneaking && cooldown && ground && !water && slide_cooldown) {

            manager.setData(entity, "unconventional:dyn/sliding", true);
            manager.setData(entity, "fiskheroes:flying", true);

        }

        manager.setData(entity, "fiskheroes:flying", false);
    
        if (entity.getData("unconventional:dyn/sliding_timer")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 0.8575);
        }
        if (entity.getData("fiskheroes:gliding")) {
            manager.setData(entity, "fiskheroes:flight_boost_timer", 1);
        }

        //Grappling
        var motionY1 = entity.motionY();
        var ground_distance = entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid();
        var sprinting = entity.isSprinting();
        var punching = entity.isPunching();
        if (!ground_distance && !punching && entity.getHeldItem().name() == "fiskheroes:grappling_gun" && motionY1 > 0.6) {
            manager.setData(entity, "unconventional:dyn/grapple", true); 
        }
        else manager.setData(entity, "unconventional:dyn/grapple", false);

    });
}

function getAttributeProfile(entity) {
	if (entity.getData("unconventional:dyn/sliding_timer")) {
        return "SLIDING";
    } 
    
    return null;
}

function slidingProfile(profile) {
    profile.inheritDefaults();
    profile.addAttribute("BASE_SPEED", 1.5, 1);
    profile.addAttribute("SPRINT_SPEED", -0.25, 1);

}

function isModifierEnabled(entity, modifier) {
    var weapon = entity.getData('unconventional:dyn/grenade_switch');
    switch (modifier.name()) {
    case "fiskheroes:controlled_flight":
        return entity.getData("unconventional:dyn/sliding");
    case modifier.id() == "sliding_transformation":
        return !entity.getData("fiskheroes:aiming") && entity.isSprinting() && entity.isOnGround() && !entity.isInWater() && entity.getData("unconventional:dyn/sliding_cooldown") == 0;
    case "fiskheroes:equipment":
        return modifier.id() == "explosive" == (weapon % 4 == 1) 
        && modifier.id() == "smoke" == (weapon % 4 == 2) 
        && modifier.id() == "neural" == (weapon % 4 == 3);
    default:
        return true;
    
    }
}

function isKeyBindEnabled(entity, keyBind) {
    var weapon = entity.getData('unconventional:dyn/grenade_switch');
    switch (keyBind) {
    case "GUN_RELOAD":
        return (entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon())) && !entity.getData("fiskheroes:aiming");
    case "UTILITY_BELT":
        return !(entity.getHeldItem().isGun() || (entity.getHeldItem().name() == "fisktag:weapon" && !entity.getHeldItem().isWeapon()));
    case "func_CYCLE_WEAPON_FLASHBAND":
        return entity.getData("fiskheroes:utility_belt_type") == 0 && weapon % 4 == 0 && !entity.getWornChestplate().nbt().getBoolean("SelectCooldown");
    case "func_CYCLE_WEAPON_EXPLOSIVE":
        return entity.getData("fiskheroes:utility_belt_type") == 0 && weapon % 4 == 1 && !entity.getWornChestplate().nbt().getBoolean("SelectCooldown");
    case "func_CYCLE_WEAPON_SMOKE":
        return entity.getData("fiskheroes:utility_belt_type") == 0 && weapon % 4 == 2 && !entity.getWornChestplate().nbt().getBoolean("SelectCooldown");
    case "func_CYCLE_WEAPON_NEURAL":
        return entity.getData("fiskheroes:utility_belt_type") == 0 && weapon % 4 == 3 && !entity.getWornChestplate().nbt().getBoolean("SelectCooldown");
    default:
        return true;
    }
}

function cycleGrenadeKey(player, manager) {
    var weapon = player.getData("unconventional:dyn/grenade_switch");
    manager.setData(player, "unconventional:dyn/grenade_switch", (weapon + 1) % 4);
	var nbt = player.getWornChestplate().nbt();
    manager.setBoolean(nbt, "SelectCooldown", true);
    return true;
}