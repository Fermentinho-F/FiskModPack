extend("fiskheroes:hero_basic");
loadTextures({
	"null": "tmf:null",
	"layer1": "tmf:null",
    "layer2": "tmf:null"
});

function init(renderer) {
	parent.init(renderer);
}
