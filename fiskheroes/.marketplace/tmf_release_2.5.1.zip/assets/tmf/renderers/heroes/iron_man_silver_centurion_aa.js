extend("tmf:iron_man_mk1_aa");
loadTextures({
	"null": "tmf:null",
	"mask": "tmf:silver_centurion/iron_man_silver_centurion_aa_mask",
	"layer1": "tmf:silver_centurion/iron_man_silver_centurion_aa_layer1",
	"layer2": "tmf:silver_centurion/iron_man_silver_centurion_aa_layer2",
	"suit_lights": "tmf:mk1/iron_man_mk1_aa_lights"
});