var LOADTEXTURES = {
};

function init(renderer, getAlien, isCurrent) {
    return {
        getTexture: entity => "null",
        render: (entity, isFirstPersonArm) => {
        }
    };
}
