function init(hero) {
    hero.setName("I'm no hero");
    hero.setTier(1);
    hero.hide();
    
    hero.setChestplate("Node");
}