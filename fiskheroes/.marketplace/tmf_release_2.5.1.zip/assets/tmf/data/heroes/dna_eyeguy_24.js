function init(hero) {
    hero.setName("Uncraftable Item - Eyeguy");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}