function init(hero) {
    hero.setName("Uncraftable Item - Wildvine");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}