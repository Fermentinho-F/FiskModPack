function init(hero) {
}
