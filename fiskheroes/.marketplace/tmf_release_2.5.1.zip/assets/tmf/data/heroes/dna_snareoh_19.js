function init(hero) {
    hero.setName("Uncraftable Item - Snare-Oh");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}