function init(hero) {
    hero.setName("Uncraftable Item - Cannonbolt");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}