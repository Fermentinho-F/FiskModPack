function init(hero) {
    hero.setName("Uncraftable Item - Ditto");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}