function init(hero) {
    hero.setName("Uncraftable Item - Frankenstrike");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}