function init(hero) {
    hero.setName("Uncraftable Item - Waybig");
    hero.setTier(1);
    hero.hide();
    hero.setChestplate("Dna");
}