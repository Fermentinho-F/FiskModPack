var ban = implement("pwt:external/switch");
function init(hero) {
    hero.setName("Sukuna");
    hero.setTier(8);
	
    hero.setChestplate("Torso");
    hero.setLeggings("Legs");
    hero.setBoots("Feets");
	
	hero.addPowers("pwt:cleave_dis");
	

	hero.addAttribute("PUNCH_DAMAGE", 7.5, 0);
    hero.addAttribute("WEAPON_DAMAGE", 2.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 2.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 0.9, 1);
    hero.addAttribute("SPRINT_SPEED", 1.1, 1);
	
	hero.addKeyBind("ENERGY_PROJECTION", "Cleave", -1);
	hero.addKeyBind("CLEAVE", "Cleave", 1);
	hero.addKeyBind("CLEAVE_FALSE", "Cleave", 1);
	hero.addKeyBind("CHARGED_BEAM", "Dismantle", 2);
	hero.addKeyBind("CHARGE_ENERGY", "key.chargeEnergy", 3);
	hero.addKeyBind("SLOW_MOTION", "Slow Motion", 4);
	hero.addKeyBindFunc("TELEPORT", teleport, "Teleport", 5);	

	hero.supplyFunction("canDischargeEnergy", false);

	hero.setModifierEnabled(isModifierEnabled);
	hero.setKeyBindEnabled(isKeyBindEnabled);
	hero.setAttributeProfile(entity => entity.getData('pwt:dyn/punishment') ? "PUNISHMENT" : null);
	hero.addAttributeProfile("PUNISHMENT", punishProfile);

	hero.setTickHandler((entity, manager) => {
		
		var cleave_output = entity.getData("pwt:dyn/cleave_output");
		var cleave_output_max = 5;
		
				

		
		
		var air_dash = !entity.isOnGround() && (entity.world().blockAt(entity.pos().add(0, 2, 0)).isSolid() || entity.world().blockAt(entity.pos().add(-1.0, 0, 0)).isSolid() || entity.world().blockAt(entity.pos().add(1, 0, 0)).isSolid() || entity.world().blockAt(entity.pos().add(0, 0, -1)).isSolid() || entity.world().blockAt(entity.pos().add(0, 0, 1.0)).isSolid())
		manager.setData(entity, "fiskheroes:invisible", entity.getData('fiskheroes:teleport_timer') > 0.6 || entity.getData('pwt:dyn/dash_timer')>0.3);
		
		// if (entity.isSprinting() && ((entity.motionY() > 0.2 && !entity.isOnGround() && entity.world().blockAt(entity.pos().add(0, -2, 0)).isSolid()) || air_dash ) && entity.isPunching() && !entity.getData('pwt:dyn/dash')) {
			// manager.setData(entity, "pwt:dyn/dash", true);
		// }
		if (entity.getData('pwt:dyn/dash_cooldown') == 1) {
			manager.setData(entity, "pwt:dyn/dash", false);
		}
		else if (entity.getData('pwt:dyn/dash_cooldown') == 0) {
			manager.setData(entity, "pwt:dyn/dash", true);
		}
		
		
		if  (entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData('fiskheroes:beam_charging')) {
			manager.setData(entity, 'pwt:dyn/trick_1', Math.floor(Math.random() * 4));
			
		}
		if  ((entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData('fiskheroes:beam_charging')) && entity.getData('pwt:dyn/smash_charge')==0) {
			manager.setDataWithNotify(entity, 'pwt:dyn/trick', Math.floor(Math.random() * 180));
			manager.setInterpolatedData(entity, 'pwt:dyn/trick_cooldown', 0);
			
		}
		if  ((entity.getData("fiskheroes:beam_shooting") != 0 && entity.getData("fiskheroes:beam_charge") == 1) || entity.getData('fiskheroes:energy_projection') ) {
			manager.setInterpolatedData(entity, 'pwt:dyn/trick_cooldown', 1);
		}
		
		///CLEAVE_PUNCH
	
		//manager.setData(entity, "fiskheroes:energy_projection", entity.getData('pwt:dyn/cleave_punch_timer')>0);
		
		if  (entity.getPunchTimer() == 0 && entity.getData('pwt:dyn/cleave_punch_timer') == 0 && entity.getData('pwt:dyn/cleave_punch_cooldown') == 0) {
			manager.setData(entity, 'pwt:dyn/cleave_punch_trick_chance', Math.floor(Math.random() * 10));			
		}
		
		if (entity.getData('pwt:dyn/cleave_punch_cooldown') == 0 && entity.getHeldItem().isEmpty() && entity.getData('fiskheroes:energy_charge') == 0) {
		manager.setData(entity, 'pwt:dyn/cleave_punch_toggle', entity.getData('pwt:dyn/cleave_punch_trick_chance') <=4  && entity.getPunchTimer()>0 ) 
		}
		else if (entity.getData('pwt:dyn/cleave_punch_timer') == 1) {
		manager.setData(entity, 'pwt:dyn/cleave_punch_toggle', false) 
		}

		manager.incrementData(entity, "pwt:dyn/cleave_punch_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_punch_toggle') );
		manager.incrementData(entity, "pwt:dyn/cleave_punch_cooldown", 0, 20 ,entity.getData('pwt:dyn/cleave_punch_timer') == 1);
		if  (!entity.getData('pwt:dyn/cleave_punch_toggle') && entity.getData('fiskheroes:energy_projection_timer') == 0 && entity.getPunchTimer() == 0 && entity.getData('pwt:dyn/cleave_punch_timer') == 0) {
			manager.setData(entity, 'pwt:dyn/cleave_punch_trick', Math.floor(Math.random() * 180));			
		}
		
	
		///CLEAVE

		manager.setData(entity, "fiskheroes:heat_vision", entity.getData('pwt:dyn/cleave_timer') >=0.3 &&  entity.getData('pwt:dyn/cleave'));

		manager.setData(entity, 'pwt:dyn/cleave_1_toggle', (entity.loop(10) <0.5 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_1_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_1_toggle'));
		if  (entity.getData('pwt:dyn/cleave_1_toggle') == false) {
			manager.setData(entity, 'pwt:dyn/cleave_1_trick', Math.floor(Math.random() * 90));			
		}
		
		manager.setData(entity, 'pwt:dyn/cleave_2_toggle', (entity.loop(10) >0.6 && entity.loop(10) <=1 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_2_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_2_toggle'));
		if  (entity.getData('pwt:dyn/cleave_2_toggle') == false) {
			manager.setData(entity, 'pwt:dyn/cleave_2_trick', Math.floor(Math.random() * 90));			
		}

		manager.setData(entity, 'pwt:dyn/cleave_3_toggle', (entity.loop(10) >0.3 && entity.loop(10) <=0.8 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_3_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_3_toggle'));
		if  (entity.getData('pwt:dyn/cleave_3_toggle') == false) {
			manager.setData(entity, 'pwt:dyn/cleave_3_trick', Math.floor(Math.random() * 90));			
		}

		manager.setData(entity, 'pwt:dyn/cleave_4_toggle', (entity.loop(10) >0.2 && entity.loop(10) <=0.6 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_4_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_4_toggle'));
		if  (entity.getData('pwt:dyn/cleave_4_toggle') == false) {
			manager.setData(entity, 'pwt:dyn/cleave_4_trick', Math.floor(Math.random() * 90));			
		}
		
		manager.setData(entity, 'pwt:dyn/cleave_5_toggle', (entity.loop(10) >0.0 && entity.loop(10) <=0.4 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_5_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_5_toggle'));
		if  (entity.getData('pwt:dyn/cleave_5_toggle') == false) {
			manager.setData(entity, 'pwt:dyn/cleave_5_trick', Math.floor(Math.random() * 90));			
		}


		
			
		manager.incrementData(entity, "fiskheroes:dyn/speed_sprint_timer", 4, entity.isSprinting() && entity.isOnGround());
		manager.incrementData(entity, "pwt:dyn/idle_timer", 20, entity.getData('fiskheroes:moving') && !entity.isSprinting() && !entity.isSneaking() && entity.isOnGround() && !entity.getData('fiskheroes:flying'));
		ban.tick(entity, manager);
	});
}

function teleport(player, manager) {
	manager.setData(player, 'fiskheroes:teleport_timer', 0);
	manager.setData(player, 'fiskheroes:teleport_delay', 8);
    return true;
}

function isModifierEnabled(entity, modifier) {
	var cleave_output = entity.getData("pwt:dyn/cleave_output");
    switch (modifier.name()) {

	case "fiskheroes:controlled_flight":
        return entity.getData('pwt:dyn/dash') && entity.isSprinting();
	case "fiskheroes:charged_beam":
        return !entity.getData('pwt:dyn/cleave');

	// case "fiskheroes:heat_vision":
        // return modifier.id() == ("cleave_beam_"+Math.floor(entity.getData('pwt:dyn/charge')*3));
	case "fiskheroes:heat_vision":
        	return true;
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
	var scale = entity.getData('fiskheroes:scale');
	
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	var creative = !nbt.getBoolean('NeedsUnlock');
	var hash = nbt.getInteger("Upgrades");
	var damage_reduction = hash >> 4 * 0 & 0xF;
	var punch_damage = hash >> 4 * 1 & 0xF;

    switch (keyBind) {	
	case "ENERGY_PROJECTION":
        return entity.getData('pwt:dyn/cleave_punch_timer')>0 && entity.getData('pwt:dyn/cleave_punch_timer') < 0.8 && entity.getData('pwt:dyn/cleave_punch_toggle');
	case "CHARGED_BEAM":
        return entity.getData('fiskheroes:energy_charge') == 0;
	case "CLEAVE_FALSE":
        return entity.getData('fiskheroes:energy_charge') == 0;

	case "CLEAVE":
        return (entity.getData('pwt:dyn/cleave_cooldown') == 0 || (entity.getData('pwt:dyn/cleave_cooldown')>0 && entity.getData('pwt:dyn/cleave')) && entity.getData('fiskheroes:beam_charge') == 0) && entity.getData('fiskheroes:energy_charge') == 0;
	
	default:
        return true;
    }
}

function punishProfile(profile) {
    profile.revokeAugments();
	profile.addAttribute("MAX_HEALTH", -10000000.0, 0);
}