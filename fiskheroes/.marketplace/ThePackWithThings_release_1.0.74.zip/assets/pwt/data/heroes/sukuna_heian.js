function init(hero) {
    hero.setName("Ryomen Sukuna");
	hero.setVersion("True Form");
    hero.setTier(9);
	
    hero.setChestplate("Torso");
    hero.setLeggings("Pants");
    hero.setBoots("Shoes");
	
	hero.addPowers("pwt:cleave_dis_heian");

	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:pwt:hiten, AttributeModifiers:[{Operation:0,UUIDLeast:1,UUIDMost:1,Amount:9,AttributeName:generic.attackDamage,Name:Attack Damage}]}", true, item => item.nbt().getString("WeaponType") == 'pwt:hiten');
	hero.addPrimaryEquipment("fisktag:weapon{WeaponType:pwt:kamutoke, AttributeModifiers:[{Operation:0,UUIDLeast:1,UUIDMost:1,Amount:5,AttributeName:generic.attackDamage,Name:Attack Damage}]}", true, item => item.nbt().getString("WeaponType") == 'pwt:kamutoke');

	hero.addAttribute("PUNCH_DAMAGE", 10.0, 0);
    hero.addAttribute("WEAPON_DAMAGE", 5.0, 0);
    hero.addAttribute("JUMP_HEIGHT", 3.0, 0);
    hero.addAttribute("FALL_RESISTANCE", 0.9, 1);
    hero.addAttribute("SPRINT_SPEED", 1.5, 1);
	

	
	hero.addKeyBind("ENERGY_PROJECTION", "Cleave", -1);
	hero.addKeyBind("CLEAVE", "Cleave", 1);
	hero.addKeyBind("CLEAVE_FALSE", "Cleave", 1);

	hero.addKeyBind("DISMANTLE_MAX", "Dismantle Max Output", 1);
	hero.addKeyBind("DISMANTLE_MAX_FALSE", "Dismantle Max Output", 1);
	
	hero.addKeyBind("KAMUTOKE", "Shake", 1);
	hero.addKeyBind("KAMUTOKE_FALSE", "Shake", 1);

	hero.addKeyBind("CHARGED_BEAM", "Dismantle", 2);
	hero.addKeyBind("CHARGE_ENERGY", "key.chargeEnergy", 3);
	hero.addKeyBind("CHANT", "Start Chant", 3);
	hero.addKeyBind("SLOW_MOTION", "Slow Motion", 4);
	hero.addKeyBindFunc("TELEPORT", teleport, "Teleport", 5);	

	hero.setHasPermission((entity, permission) => permission == "USE_KAMUTOKE");
    hero.supplyFunction("canAim", entity => entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString('WeaponType') == 'pwt:kamutoke');
	
	hero.supplyFunction("canDischargeEnergy", false);
	hero.setDefaultScale(1.2);
	
	hero.setDamageProfile(entity => true ? "PUNCH" : null);
    	hero.addDamageProfile("PUNCH", {
        	"types": {
            	"BLUNT": 1.0
        	},
        	"properties": {
            	"HIT_COOLDOWN": 10
        	}
   	 });	

	hero.setModifierEnabled(isModifierEnabled);
	hero.setKeyBindEnabled(isKeyBindEnabled);

	hero.setTickHandler((entity, manager) => {
		var hiten = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString('WeaponType') == 'pwt:hiten'
		var air_dash = !entity.isOnGround() && (entity.world().blockAt(entity.pos().add(0, 2, 0)).isSolid() || entity.world().blockAt(entity.pos().add(-1.0, 0, 0)).isSolid() || entity.world().blockAt(entity.pos().add(1, 0, 0)).isSolid() || entity.world().blockAt(entity.pos().add(0, 0, -1)).isSolid() || entity.world().blockAt(entity.pos().add(0, 0, 1.0)).isSolid())
		manager.setData(entity, "fiskheroes:invisible", entity.getData('fiskheroes:teleport_timer') > 0.6 || entity.getData('pwt:dyn/dash_timer')>0.3);
		///AIR DAS H
		if (entity.getData('pwt:dyn/dash_cooldown') == 1 || (hiten && entity.isSprinting() && entity.getData('pwt:dyn/float_cooldown') == 0) || entity.getData('pwt:dyn/float') ) {
			manager.setData(entity, "pwt:dyn/dash", false);
		}
		else if (entity.getData('pwt:dyn/dash_cooldown') == 0 && !(hiten && entity.isSprinting() && entity.getData('pwt:dyn/float_timer') == 0)) {
			manager.setData(entity, "pwt:dyn/dash", true);
		}

		///FLIGHT_HITEN
		if (entity.getData('fiskheroes:flying') && hiten && entity.getData('pwt:dyn/float_cooldown') == 0) {
			manager.setData(entity, "pwt:dyn/float", true);
		}
		else if (!entity.getData('fiskheroes:flying')){
			manager.setData(entity, "pwt:dyn/float", false);
		}
       		manager.incrementData(entity, "pwt:dyn/anim_2_timer", 8, 6, hiten && entity.getData("fiskheroes:flying") && entity.motionX() == 0 && entity.motionZ() == 0 && !entity.isPunching() && entity.getData("pwt:dyn/max_output") == 0 );

		
		///MAIN HANDS
		if  (!entity.isPunching() && entity.getPunchTimer() == 0 ) {
			manager.setDataWithNotify(entity, 'pwt:dyn/punch', Math.floor(Math.random() * 2));
			manager.setDataWithNotify(entity, 'pwt:dyn/punch2', entity.getData('pwt:dyn/chant_timer') == 0 ? Math.floor(Math.random() * 4) : 0);			
		}
		
		if  (entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData('fiskheroes:beam_charging') && entity.getData('pwt:dyn/cleave_timer') == 0 ) {
			manager.setDataWithNotify(entity, 'pwt:dyn/trick_2', entity.getHeldItem().isEmpty() || entity.getData('pwt:dyn/chant_timer')>0 ? 2 : Math.floor(Math.random() * 2));
		}

		///DISMANTLE
		if  (entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData('fiskheroes:beam_charging')) {
			manager.setDataWithNotify(entity, 'pwt:dyn/trick_1', Math.floor(Math.random() * 4));
		}
		if  ((entity.getData("fiskheroes:beam_charge") == 0 && !entity.getData('fiskheroes:beam_charging')) && entity.getData('pwt:dyn/smash_charge')==0 && entity.getData('pwt:dyn/dismantle_max_timer') == 0) {
			manager.setDataWithNotify(entity, 'pwt:dyn/trick', Math.floor(Math.random() * 180));
			manager.setInterpolatedData(entity, 'pwt:dyn/trick_cooldown', 0);
			
		}
		if  ((entity.getData("fiskheroes:beam_shooting") != 0 && entity.getData("fiskheroes:beam_charge") == 1) || entity.getData('fiskheroes:energy_projection') || entity.getData('pwt:dyn/dismantle_max_timer') == 0) {
			manager.setInterpolatedData(entity, 'pwt:dyn/trick_cooldown', 1);
		}
		
		///KAMUTOKE
		manager.incrementData(entity, "pwt:dyn/kamutoke_replace_timer", 6, 8, entity.getData('pwt:dyn/kamutoke') && entity.getData('pwt:dyn/kamutoke_timer')>0.4);

		if (entity.getData('pwt:dyn/kamutoke')) {
		manager.setData(entity, "fiskheroes:heat_vision", entity.getData('pwt:dyn/kamutoke') && entity.getData('pwt:dyn/kamutoke_timer')>0.4);
		}

		///MAX_OUTPUT_DISMANTLE
		
		
		manager.incrementData(entity, "pwt:dyn/max_output", 140, 0, entity.getData('pwt:dyn/chant_timer') == 1);

		manager.incrementData(entity, "pwt:dyn/chant_recharge_cooldown", 0, 280, entity.getData('pwt:dyn/max_output') == 1);

		if (entity.getData('pwt:dyn/chant_timer') == 1) {
		manager.setData(entity, "fiskheroes:heat_vision", entity.getData('pwt:dyn/dismantle_max_timer') >=0.3 &&  entity.getData('pwt:dyn/dismantle_max'));
		}
		manager.incrementData(entity, "pwt:dyn/dismantle_max_replace_timer", 6, 8,entity.getData("fiskheroes:heat_vision") && entity.getData('pwt:dyn/chant_timer') == 1 && entity.getData('pwt:dyn/dismantle_max_timer')>0);
		
		if (entity.getData('pwt:dyn/dismantle_max_cooldown') == 1 || (entity.getData("fiskheroes:time_since_damaged")>0 && entity.getData("fiskheroes:time_since_damaged")<5 && entity.getData('pwt:dyn/max_output') != 1 ) ) {
			manager.setData(entity, 'pwt:dyn/chant', false);	
		}

		
		///CLEAVE_PUNCH
	
		if  (entity.getPunchTimer() == 0 && entity.getData('pwt:dyn/cleave_punch_timer') == 0 && entity.getData('pwt:dyn/cleave_punch_cooldown') == 0) {
			manager.setData(entity, 'pwt:dyn/cleave_punch_trick_chance', Math.floor(Math.random() * 10));			
		}
		
		if (entity.getData('pwt:dyn/cleave_punch_cooldown') == 0  && entity.getData('fiskheroes:energy_charge') == 0) {
		manager.setData(entity, 'pwt:dyn/cleave_punch_toggle', entity.getData('pwt:dyn/cleave_punch_trick_chance') <=6  && entity.getPunchTimer()>0 ) 
		}
		else if (entity.getData('pwt:dyn/cleave_punch_timer') == 1) {
		manager.setData(entity, 'pwt:dyn/cleave_punch_toggle', false) 
		}

		manager.incrementData(entity, "pwt:dyn/cleave_punch_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_punch_toggle') );
		manager.incrementData(entity, "pwt:dyn/cleave_punch_cooldown", 0, 20 ,entity.getData('pwt:dyn/cleave_punch_timer') == 1);
		if  (!entity.getData('pwt:dyn/cleave_punch_toggle') && entity.getData('fiskheroes:energy_projection_timer') == 0 && entity.getPunchTimer() == 0 && entity.getData('pwt:dyn/cleave_punch_timer') == 0) {
			manager.setData(entity, 'pwt:dyn/cleave_punch_trick', Math.floor(Math.random() * 180));			
		}
		
		///CLEAVE
		
		if (entity.getData('pwt:dyn/chant_timer') == 0 && entity.getData('pwt:dyn/cleave_timer')>0) {
		manager.setData(entity, "fiskheroes:heat_vision", entity.getData('pwt:dyn/cleave_timer') >=0.3 &&  entity.getData('pwt:dyn/cleave'));
		}
		manager.incrementData(entity, "pwt:dyn/cleave_replace_timer", 5, entity.getData("fiskheroes:heat_vision") && entity.getData('pwt:dyn/chant_timer') == 0 && entity.getData('pwt:dyn/cleave_timer')>0);

		manager.setData(entity, 'pwt:dyn/cleave_1_toggle', (entity.loop(10) <0.5 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_1_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_1_toggle'));
		if  (entity.getData('pwt:dyn/cleave_1_toggle') == false) {
			manager.setDataWithNotify(entity, 'pwt:dyn/cleave_1_trick', Math.floor(Math.random() * 90));			
		}
		
		manager.setData(entity, 'pwt:dyn/cleave_2_toggle', (entity.loop(10) >0.6 && entity.loop(10) <=1 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_2_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_2_toggle'));
		if  (entity.getData('pwt:dyn/cleave_2_toggle') == false) {
			manager.setDataWithNotify(entity, 'pwt:dyn/cleave_2_trick', Math.floor(Math.random() * 90));			
		}

		manager.setData(entity, 'pwt:dyn/cleave_3_toggle', (entity.loop(10) >0.3 && entity.loop(10) <=0.8 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_3_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_3_toggle'));
		if  (entity.getData('pwt:dyn/cleave_3_toggle') == false) {
			manager.setDataWithNotify(entity, 'pwt:dyn/cleave_3_trick', Math.floor(Math.random() * 90));			
		}

		manager.setData(entity, 'pwt:dyn/cleave_4_toggle', (entity.loop(10) >0.2 && entity.loop(10) <=0.6 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_4_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_4_toggle'));
		if  (entity.getData('pwt:dyn/cleave_4_toggle') == false) {
			manager.setDataWithNotify(entity, 'pwt:dyn/cleave_4_trick', Math.floor(Math.random() * 90));			
		}
		
		manager.setData(entity, 'pwt:dyn/cleave_5_toggle', (entity.loop(10) >0.0 && entity.loop(10) <=0.4 )) 
		manager.incrementData(entity, "pwt:dyn/cleave_5_timer", 5, 0 ,entity.getData('pwt:dyn/cleave_5_toggle'));
		if  (entity.getData('pwt:dyn/cleave_5_toggle') == false) {
			manager.setDataWithNotify(entity, 'pwt:dyn/cleave_5_trick', Math.floor(Math.random() * 90));			
		}
			
		manager.incrementData(entity, "fiskheroes:dyn/speed_sprint_timer", 4, entity.isSprinting() && entity.isOnGround());
		manager.incrementData(entity, "pwt:dyn/idle_timer", 20, entity.getData('fiskheroes:moving') && !entity.isSprinting() && !entity.isSneaking() && entity.isOnGround() && !entity.getData('fiskheroes:flying'));
	});
}

function teleport(player, manager) {
	manager.setData(player, 'fiskheroes:teleport_timer', 0);
	manager.setData(player, 'fiskheroes:teleport_delay', 8);
    return true;
}

function isModifierEnabled(entity, modifier) {
	var hiten = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString('WeaponType') == 'pwt:hiten'

    switch (modifier.name()) {
	case "fiskheroes:charged_beam":
        return !entity.getData('pwt:dyn/cleave') && entity.getData('pwt:dyn/max_output')<1;
	case "fiskheroes:controlled_flight":
        return  modifier.id() == 'flight_dash'== (entity.getData('pwt:dyn/dash') && entity.isSprinting()) && modifier.id() == 'flight_float' == (hiten && ((entity.getData('pwt:dyn/float_cooldown') == 0 && !entity.getData('pwt:dyn/float') || entity.getData('pwt:dyn/float')) ) );
	case "fiskheroes:heat_vision":
        return (modifier.id() == 'cleave_beam' == entity.getData('pwt:dyn/cleave')) && (modifier.id() == 'dismantle_max_output_beam' == entity.getData('pwt:dyn/chant_timer') == 1) && (modifier.id() == 'kamutoke_beam' == entity.getData('pwt:dyn/kamutoke'));
    default:
        return true;
    }
}

function isKeyBindEnabled(entity, keyBind) {
	var scale = entity.getData('fiskheroes:scale');
	
	var item = entity.getEquipmentInSlot(3);
	var nbt = item.nbt();
	var creative = !nbt.getBoolean('NeedsUnlock');
	var hash = nbt.getInteger("Upgrades");
	var damage_reduction = hash >> 4 * 0 & 0xF;
	var punch_damage = hash >> 4 * 1 & 0xF;
	var kamutoke = entity.getHeldItem().name() == "fisktag:weapon" && entity.getHeldItem().nbt().getString('WeaponType') == 'pwt:kamutoke'

    switch (keyBind) {
	case "TELEPORT":
        return !entity.getData('pwt:dyn/float');

	case "CHARGE_ENERGY":
        return !entity.isSneaking() || entity.getData('pwt:dyn/chant_recharge_cooldown') > 0;
	case "CHANT":
        return entity.isSneaking() && entity.getData('pwt:dyn/chant_recharge_cooldown') == 0;

	case "ENERGY_PROJECTION":
        return entity.getData('pwt:dyn/cleave_punch_timer')>0 && entity.getData('pwt:dyn/cleave_punch_timer') < 0.8 && entity.getData('pwt:dyn/cleave_punch_toggle');
	case "CHARGED_BEAM":
        return entity.getData('fiskheroes:energy_charge') == 0;
	case "CLEAVE_FALSE":
        return entity.getData('fiskheroes:energy_charge') == 0 && entity.getData('pwt:dyn/chant_timer') == 0  && !kamutoke;

	case "CLEAVE":
        return (entity.getData('pwt:dyn/cleave_cooldown') == 0 || (entity.getData('pwt:dyn/cleave_cooldown')>0 && entity.getData('pwt:dyn/cleave')) && entity.getData('fiskheroes:beam_charge') == 0) && entity.getData('fiskheroes:energy_charge') == 0 && entity.getData('pwt:dyn/chant_timer') == 0 && entity.getData('pwt:dyn/chant_recharge_cooldown') <= 0.95 && !kamutoke;

	case "DISMANTLE_MAX_FALSE":
        return entity.getData('fiskheroes:energy_charge') == 0 && entity.getData('pwt:dyn/chant_timer') >0;

	case "DISMANTLE_MAX":
        return (entity.getData('pwt:dyn/dismantle_max_cooldown') == 0 || (entity.getData('pwt:dyn/dismantle_max_cooldown')>0 && entity.getData('pwt:dyn/dismantle_max')) && entity.getData('fiskheroes:beam_charge') == 0) && entity.getData('fiskheroes:energy_charge') == 0 && entity.getData('pwt:dyn/max_output') == 1;

	case "KAMUTOKE_FALSE":
        return entity.getData('pwt:dyn/chant_timer') == 0 && entity.getData('pwt:dyn/cleave_timer') == 0 && kamutoke;

	case "KAMUTOKE":
        return (entity.getData('pwt:dyn/kamutoke_cooldown') == 0 || (entity.getData('pwt:dyn/kamutoke_cooldown')>0 && entity.getData('pwt:dyn/kamutoke'))) && entity.getData('pwt:dyn/chant_timer') == 0 && entity.getData('pwt:dyn/cleave_timer') == 0 && kamutoke;
	
	default:
        return true;
    }
}