loadTextures({
    "base": "pwt:kamutoke"
});

var utils = implement("fisktag:external/utils");

function init(renderer) {
    var model = utils.createModel(renderer, "pwt:kamutoke", "base");
    renderer.setModel(model);
	
	utils.bindBeam(renderer, "fiskheroes:lightning_cast", 0xA2FFCE, [
        { "firstPerson": [-3.7, 9.0, -15.0], "offset": [-3.0, -500.0, -1800000.5], "size": [3.5, 3.5] }
    ]);
	
}

function render(renderer, entity, glProxy, renderType, scopeTimer, recoil, isLeftSide) {
	var kamutoke_timer = entity.getData("pwt:dyn/kamutoke_cooldown") != 0 && entity.getInterpolatedData("pwt:dyn/kamutoke") ? Math.min(1.5*Math.sin(Math.PI*entity.getInterpolatedData('pwt:dyn/kamutoke_timer'),1)) : 0;
	
	///x:0.04
	if (renderType === "EQUIPPED_FIRST_PERSON") {
		glProxy.translate(0.0+0.35*kamutoke_timer, 0.0-0.4*kamutoke_timer, -0.2);
		
		glProxy.rotate(10, 0, -1, -1);
		glProxy.rotate(15*Math.sin(2*entity.loop(10)*Math.PI*kamutoke_timer), 0, 0, 1);
		
		glProxy.rotate(10, 0, -1, 0);
		// glProxy.rotate(10, 0, -1, 0);
		// glProxy.rotate(15, -1, 0, 0);
		// glProxy.rotate(35, 1, 0, 0);
		
		glProxy.scale(0.9);
	}
    else if (renderType === "INVENTORY" || renderType === "ENTITY") {
		// glProxy.translate(0.3, 0.25, 0.0);
		glProxy.rotate(45, 0, -1, 0);
		glProxy.rotate(45, -1, 0, 0);
		glProxy.rotate(15, 0, 0, -1);
    }
	else if (renderType !== "INVENTORY" || renderType !== "ENTITY") {
		// glProxy.rotate(35*Math.min(Math.sin(Math.PI*entity.getPunchTimerInterpolated())*2,1), 1, 0, 0);
    }
	glProxy.translate(-0.05, -0.05, 0.0);
	glProxy.scale(1.5);

}
