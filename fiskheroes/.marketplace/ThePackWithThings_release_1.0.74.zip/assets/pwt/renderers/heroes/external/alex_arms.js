function create(renderer, texture, lights, override_opacity) {
    var armRight_model = renderer.createResource("MODEL", "pwt:armRight_alex");
    var armRight = renderer.createEffect("fiskheroes:model").setModel(armRight_model);
    armRight.anchor.set("rightArm");
	
	var armleft_model = renderer.createResource("MODEL", "pwt:armLeft_alex");
    var armleft = renderer.createEffect("fiskheroes:model").setModel(armleft_model);
    armleft.anchor.set("leftArm");
	
	if (typeof lights !== "undefined") {
        armRight_model.texture.set(texture, lights);
		armleft_model.texture.set(texture, lights);
    }
    else {
        armRight_model.texture.set(texture);
		armleft_model.texture.set(texture);
    }
	

	var alex_opacity = renderer.bindProperty("fiskheroes:opacity").setOpacity((entity, renderLayer) => {
		return entity.isWearingFullSuit() || (entity.is("DISPLAY") && !entity.as("DISPLAY").isStatic() && entity.isWearingFullSuit()) ? 0.9999 : 1;
	});
	
	
	

    return {
        armRight_model: armRight_model,
		armleft_model: armleft_model,
        armRight: armRight,
        armleft: armleft,
        render: (entity, op, mirror) => {
			if ((entity.isWearingFullSuit() && !entity.is("DISPLAY")) || (entity.is("DISPLAY") && ((!entity.as("DISPLAY").isStatic() && entity.isWearingFullSuit())|| entity.as("DISPLAY").isInGui() ))) {
				
				armRight.opacity = op;
				//armRight.render();
				armleft.opacity = op;
				//armleft.render();
				if (typeof mirror !== "undefined") {
					if (mirror === 'L') {
						armleft.render();
					}
					else if (mirror === 'R') {
						armRight.render();
					}
				}
				else {
					armleft.render();
					armRight.render();
				}
			}
        }
    };
}
